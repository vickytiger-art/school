import React, { useEffect, useState } from 'react';
import { NavLink } from 'react-router-dom';
import PropTypes from 'prop-types'; // Add this import
import SimpleBar from 'simplebar-react';
import 'simplebar-react/dist/simplebar.min.css';
import { CBadge, CNavLink, CSidebarNav, CNavItem } from '@coreui/react';
import CIcon from '@coreui/icons-react';
import { cilDrop } from '@coreui/icons';

export const AppSidebarNav = ({ items }) => {
  const [classes, setClasses] = useState([]);

  useEffect(() => {
    fetch('http://localhost:5000/classes')
      .then((response) => {
        if (!response.ok) {
          throw new Error('Network response was not ok');
        }
        return response.json();
      })
      .then((data) => {
        const filteredClasses = data.filter((item) => item.status === '1');
        setClasses(filteredClasses);
      })
      .catch((error) => {
        console.error('Error fetching classes:', error);
      });
  }, []);

  const navLink = (name, icon, badge, indent = false) => (
    <>
      {icon || (indent && <span className="nav-icon"><span className="nav-icon-bullet"></span></span>)}
      {name}
      {badge && <CBadge color={badge.color} className="ms-auto">{badge.text}</CBadge>}
    </>
  );

  const navItem = (item, index, indent = false) => {
    const { component, name, badge, icon, ...rest } = item;
    const Component = component;
    return (
      <Component as="div" key={index}>
        {rest.to || rest.href ? (
          <CNavLink {...(rest.to && { as: NavLink })} {...rest}>
            {navLink(name, icon, badge, indent)}
          </CNavLink>
        ) : (
          navLink(name, icon, badge, indent)
        )}
      </Component>
    );
  };

  const staticItems = [
    {
      component: CNavItem,
      name: 'Dashboard',
      to: '/dashboard',
      icon: <CIcon icon={cilDrop} customClassName="nav-icon" />,
    },
    {
      component: CNavItem,
      name: 'Add Classes',
      to: '/classes/addclasses',
      icon: <CIcon icon={cilDrop} customClassName="nav-icon" />,
    },
  ];

  const filteredItems = classes.map((classItem) => {
    // Convert the class name to lowercase and remove spaces
    let className = classItem.class_name.toLowerCase().replace(/\s+/g, '');
  
    // Remove any existing "class" from the name, then add "class" only if it starts with a digit
    if (/^\d/.test(className)) {
      className = `class${className.replace(/class/i, '')}`;
    }
  
    return {
      component: CNavItem,
      name: classItem.class_name, // Keep the original name for display
      to: `/classes/${className}`, // Use the modified name for the URL
      icon: <CIcon icon={cilDrop} customClassName="nav-icon" />,
    };
  });
  
  // Merge static menu items with the dynamic ones
  const menuItems = [...staticItems, ...filteredItems];
  
  // Render the menu
  return (
    <CSidebarNav as={SimpleBar}>
      {menuItems.map((item, index) =>
        item.items ? navGroup(item, index) : navItem(item, index)
      )}
    </CSidebarNav>
  );
  
  
  
};

AppSidebarNav.propTypes = {
  items: PropTypes.arrayOf(PropTypes.any).isRequired, // Correctly defining prop types
};
