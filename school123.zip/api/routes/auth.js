const express = require('express');
const router = express.Router();
const authController = require('../controllers/authController');
const multer = require('multer');
const path = require('path');
const { addTeacher, editTeacher, getTeachers } = require('../controllers/teacherController');
const { addStudent, editStudent, getStudents, getStudentById, deleteReport, getReportsByStudent, uploadReport } = require('../controllers/studentController');
const { addFees, editFees, getFees } = require('../controllers/feesController');
const { verifyToken } = require('../middleware/validateToken');


// Login route
router.post('/login', authController.login);

// Add or update class status route
router.post('/addOrUpdateClasses', verifyToken, authController.addOrUpdateClasses);
router.get('/getClasses', verifyToken, authController.getClasses);


// File upload config for student files (Moved from studentController)
const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, 'uploads/students/'); // Store student files in a specific directory
    },
    filename: (req, file, cb) => {
        const uniqueName = `${Date.now()}-${file.originalname}`;
        cb(null, uniqueName); // Generate a unique name for each file
    }
});

const upload = multer({ storage });

// Use the upload middleware for file uploads in student routes
router.post('/addstudent', upload.fields([
    { name: 'profilephoto', maxCount: 1 },
    { name: 'adharcard', maxCount: 1 }
]), addStudent); // Corrected: addStudent is now passed correctly

router.post('/editstudent/:id', upload.fields([
    { name: 'profilephoto', maxCount: 1 },
    { name: 'adharcard', maxCount: 1 }
]), editStudent); // Corrected: editStudent is now passed correctly

router.get('/getStudents', getStudents);
router.get('/getStudentById/:id', getStudentById);

// Report Upload
router.post(
    '/uploadReport',
    upload.single('marksheet'), // Only one file per report
    uploadReport
  );
  
  // Get reports by class and roll number
  router.get('/getReports/:class/:rollno', getReportsByStudent);
  
  // Delete a specific report by ID
  router.delete('/deleteReport/:id', deleteReport);
    

// Teachers routes
router.post('/add', upload.fields([
    { name: 'photo', maxCount: 1 },
    { name: 'aadhaarCard', maxCount: 1 },
    { name: 'voterCard', maxCount: 1 },
    { name: 'drivingLicense', maxCount: 1 },
    { name: 'panCard', maxCount: 1 }
]), addTeacher);

router.put('/edit/:id', upload.fields([
    { name: 'photo', maxCount: 1 },
    { name: 'aadhaarCard', maxCount: 1 },
    { name: 'voterCard', maxCount: 1 },
    { name: 'drivingLicense', maxCount: 1 },
    { name: 'panCard', maxCount: 1 }
]), editTeacher);

router.get('/all', getTeachers);

//fees

router.post('/addFees', addFees);
router.put('/editFees/:id', editFees);
router.get('/getFees', getFees);

module.exports = router;
