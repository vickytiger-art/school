const express = require('express');
const router = express.Router();
const multer = require('multer');
const path = require('path');
const { addTeacher, editTeacher, getTeachers } = require('../controllers/teacherController');

// File upload config
const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, 'uploads/');
    },
    filename: (req, file, cb) => {
        const uniqueName = `${Date.now()}-${file.originalname}`;
        cb(null, uniqueName);
    }
});
const upload = multer({ storage });

const multiUpload = upload.fields([
    { name: 'photo', maxCount: 1 },
    { name: 'aadhaarCard', maxCount: 1 },
    { name: 'voterCard', maxCount: 1 },
    { name: 'drivingLicense', maxCount: 1 },
    { name: 'panCard', maxCount: 1 }
]);

router.post('/add', multiUpload, addTeacher);
router.put('/edit/:id', multiUpload, editTeacher);
router.get('/all', getTeachers);

module.exports = router;
