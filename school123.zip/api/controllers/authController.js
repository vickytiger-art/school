// controllers/authController.js
const db = require('../db');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');

exports.login = (req, res) => {
  const { username, password } = req.body;

  db.query('SELECT * FROM users WHERE username = ?', [username], async (err, results) => {
    if (err) return res.status(500).json({ message: 'Server error' });
    if (results.length === 0) return res.status(401).json({ message: 'Invalid username or password' });

    const user = results[0];

    // const isMatch = await bcrypt.compare(password, user.password);
    // if (!isMatch) return res.status(401).json({ message: 'Invalid username or password' });

      // ✅ Plain password check (NO bcrypt)
      if (password !== user.password) {
        return res.status(401).json({ message: 'Invalid username or password' });
      }

    const token = jwt.sign(
      { id: user.id, username: user.username, role: user.role },
      process.env.JWT_SECRET,
      { expiresIn: '2h' }
    );

    let roleName = 'Unknown';
    if (user.role == 1) roleName = 'Admin/Principal';
    else if (user.role == 2) roleName = 'Teacher';
    else if (user.role == 3) roleName = 'Student';

    res.status(200).json({
      message: 'Login successful',
      token,
      user: {
        id: user.id,
        username: user.username,
        role: user.role,
        roleName
      }
    });
  });
};

exports.addOrUpdateClasses = (req, res) => {
    const classIds = req.body.classIds;  // Expecting an array of IDs
  
    if (!Array.isArray(classIds)) {
      return res.status(400).json({ message: 'Invalid class ID list format' });
    }
  
    const today = new Date().toISOString().slice(0, 10); // YYYY-MM-DD
  
    // 1. Set all classes' status to 0 first
    const resetQuery = 'UPDATE classes SET status = 0';
    db.query(resetQuery, (err) => {
      if (err) return res.status(500).json({ message: 'Failed to reset statuses' });
  
      // 2. Update the status of classes in the request (set to status = 1)
      classIds.forEach((classId) => {
        const checkQuery = 'SELECT * FROM classes WHERE id = ?';
        db.query(checkQuery, [classId], (err, results) => {
          if (err) return;
  
          if (results.length > 0) {
            // ✅ Class exists → update status = 1
            const updateQuery = 'UPDATE classes SET status = 1, date = ? WHERE id = ?';
            db.query(updateQuery, [today, classId]);
          } else {
            // ✅ Class ID doesn't exist in DB
            console.log(`Class with ID ${classId} does not exist.`);
          }
        });
      });
  
      res.status(200).json({ message: 'Classes updated successfully' });
    });
  };

  exports.getClasses = (req, res) => {
    const getQuery = 'SELECT * FROM classes';
  
    db.query(getQuery, (err, results) => {
      if (err) {
        console.error('Failed to fetch classes:', err);
        return res.status(500).json({ message: 'Failed to fetch classes' });
      }
  
      res.status(200).json(results);
    });
  };
  
