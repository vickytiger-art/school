const db = require('../db');
const fs = require('fs');
const path = require('path');

exports.addTeacher = (req, res) => {
    const {
        name, fatherName, dob, joiningDate, mobile, email, jobExperience,
        gender, salary, description, Assignclass, rating, presentAddress,
        permanentAddress, qualification, nationality, religion,
        accountHolderName, bankAccountNumber, ifscCode
    } = req.body;

    // File handling
    const photo = req.files?.photo?.[0]?.filename || '';
    const aadhaarCard = req.files?.aadhaarCard?.[0]?.filename || '';
    const voterCard = req.files?.voterCard?.[0]?.filename || '';
    const drivingLicense = req.files?.drivingLicense?.[0]?.filename || '';
    const panCard = req.files?.panCard?.[0]?.filename || '';

    const insertQuery = `
        INSERT INTO teachers (
            name, fatherName, dob, joiningDate, mobile, email, jobExperience, gender,
            salary, description, rating, presentAddress, permanentAddress,
            qualification, nationality, religion, accountHolderName,
            bankAccountNumber, ifscCode, photo, aadhaarCard, voterCard,
            drivingLicense, panCard, assignClass
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `;

    db.query(insertQuery, [
        name, fatherName, dob, joiningDate, mobile, email, jobExperience, gender,
        salary, description, rating, presentAddress, permanentAddress,
        qualification, nationality, religion, accountHolderName,
        bankAccountNumber, ifscCode, photo, aadhaarCard, voterCard,
        drivingLicense, panCard, Assignclass
    ], (err, result) => {
        if (err) return res.status(500).json({ message: 'Database error', error: err });
        res.status(200).json({ message: 'Teacher added successfully', teacherId: result.insertId });
    });
};

exports.editTeacher = (req, res) => {
    const teacherId = req.params.id;
    const {
        name, fatherName, dob, joiningDate, mobile, email, jobExperience,
        gender, salary, description, Assignclass, rating, presentAddress,
        permanentAddress, qualification, nationality, religion,
        accountHolderName, bankAccountNumber, ifscCode
    } = req.body;

    const updateQuery = `
        UPDATE teachers SET
        name=?, fatherName=?, dob=?, joiningDate=?, mobile=?, email=?, jobExperience=?, gender=?,
        salary=?, description=?, rating=?, presentAddress=?, permanentAddress=?,
        qualification=?, nationality=?, religion=?, accountHolderName=?,
        bankAccountNumber=?, ifscCode=?, assignClass=?
        WHERE id=?
    `;

    db.query(updateQuery, [
        name, fatherName, dob, joiningDate, mobile, email, jobExperience, gender,
        salary, description, rating, presentAddress, permanentAddress,
        qualification, nationality, religion, accountHolderName,
        bankAccountNumber, ifscCode, Assignclass, teacherId
    ], (err, result) => {
        if (err) return res.status(500).json({ message: 'Database error', error: err });
        res.status(200).json({ message: 'Teacher updated successfully' });
    });
};

exports.getTeachers = (req, res) => {
    db.query('SELECT * FROM teachers', (err, results) => {
        if (err) return res.status(500).json({ message: 'Database error', error: err });
        res.status(200).json(results);
    });
};
