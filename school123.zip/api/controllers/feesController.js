// controllers/feesController.js
const db = require('../db');

// Add Fees
exports.addFees = (req, res) => {
    const { rollno, class: className, name, fathersname, totalfees, submitfees, remainingfees } = req.body;

    const insertQuery = `
        INSERT INTO fees (rollno, class, name, fathersname, totalfees, submitfees, remainingfees)
        VALUES (?, ?, ?, ?, ?, ?, ?)
    `;

    db.query(insertQuery, [rollno, className, name, fathersname, totalfees, submitfees, remainingfees], (err, result) => {
        if (err) return res.status(500).json({ message: 'Error adding fees', error: err });
        res.status(200).json({ message: 'Fees record added successfully' });
    });
};

// Edit Fees
exports.editFees = (req, res) => {
    try {
        const { id } = req.params;
        const { totalfees, submitfees, remainingfees } = req.body;

        const query = `
            UPDATE fees SET
            totalfees = ?, submitfees = ?, remainingfees = ?
            WHERE id = ?
        `;

        db.query(query, [totalfees, submitfees, remainingfees, id], (err, result) => {
            if (err) {
                console.error('Database error:', err);
                return res.status(500).json({ 
                    success: false,
                    message: 'Error updating fees',
                    error: err.message 
                });
            }

            if (result.affectedRows === 0) {
                return res.status(404).json({ 
                    success: false,
                    message: 'Fee record not found' 
                });
            }

            res.status(200).json({ 
                success: true,
                message: 'Fees updated successfully' 
            });
        });
    } catch (error) {
        console.error('Server error:', error);
        res.status(500).json({ 
            success: false,
            message: 'Server error',
            error: error.message 
        });
    }
};

// Get All Fees
exports.getFees = (req, res) => {
    try {
        const { class: className } = req.query;
        
        if (!className) {
            return res.status(400).json({ 
                success: false,
                message: 'Class parameter is required' 
            });
        }

        const query = 'SELECT * FROM fees WHERE class = ?';
        
        db.query(query, [className], (err, results) => {
            if (err) {
                console.error('Database error:', err);
                return res.status(500).json({ 
                    success: false,
                    message: 'Error fetching fees',
                    error: err.message 
                });
            }
            
            res.status(200).json({ 
                success: true,
                data: results 
            });
        });
    } catch (error) {
        console.error('Server error:', error);
        res.status(500).json({ 
            success: false,
            message: 'Server error',
            error: error.message 
        });
    }
};
