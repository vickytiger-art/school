const db = require('../db');
const multer = require('multer');
const path = require('path');

// Configure storage for file uploads
const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, 'uploads/students/');
    },
    filename: (req, file, cb) => {
        const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
        cb(null, file.fieldname + '-' + uniqueSuffix + path.extname(file.originalname));
    }
});

// File filter to accept only images
const fileFilter = (req, file, cb) => {
    if (file.mimetype.startsWith('image/')) {
        cb(null, true);
    } else {
        cb(new Error('Only image files are allowed!'), false);
    }
};

// Initialize upload middleware
const upload = multer({
    storage: storage,
    fileFilter: fileFilter,
    limits: {
        fileSize: 5 * 1024 * 1024 // 5MB file size limit
    }
});

// Handle multiple file uploads (profile photo and aadhaar card)
exports.uploadFiles = upload.fields([
    { name: 'profilephoto', maxCount: 1 },
    { name: 'adharcard', maxCount: 1 }
]);

// Add Student
exports.addStudent = (req, res) => {
    try {
        const {
            rollno, class: className, section, thirdchild, name, fatherName, dob,
            admissiondate, mobile, email, description, assignclass, presentAddress, permanentAddress,
            totalfees, duefees, paidfees
        } = req.body;

        // Get uploaded file paths
        const files = req.files;
        const profilephoto = files['profilephoto'] ? files['profilephoto'][0].filename : null;
        const adharcard = files['adharcard'] ? files['adharcard'][0].filename : null;

        // Calculate fees if not provided
        const calculatedDueFees = duefees || (totalfees - (paidfees || 0));
        const calculatedPaidFees = paidfees || (totalfees - (duefees || 0));

        const insertQuery = `
            INSERT INTO students 
            (rollno, class, section, thirdchild, name, fathername, dob, admissiondate,
             mobno, email, \`desc\`, assignclass, persentaddress, address, adharcard, 
             profilephoto, totalfees, duefees, paidfees)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        `;
        
        const values = [
            rollno, className, section, thirdchild, name, fatherName, dob, admissiondate,
            mobile, email, description, assignclass, presentAddress, permanentAddress, adharcard, 
            profilephoto, totalfees, calculatedDueFees, calculatedPaidFees
        ];

        db.query(insertQuery, values, (err, result) => {
            if (err) {
                console.error('Database error:', err);
                return res.status(500).json({ 
                    success: false,
                    message: 'Error adding student',
                    error: err.message 
                });
            }
            
            // NEW CODE: Insert into fees table
            const feesInsertQuery = `
                INSERT INTO fees 
                (rollno, class, name, fathersname, totalfees, submitfees, remainingfees)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            `;
            
            const feesValues = [
                rollno, className, name, fatherName, 
                totalfees || 0, calculatedPaidFees || 0, calculatedDueFees || 0
            ];
            
            db.query(feesInsertQuery, feesValues, (feesErr, feesResult) => {
                if (feesErr) {
                    console.error('Database error (fees table):', feesErr);
                    // Continue with success response even if fees insert fails
                }
                
                res.status(201).json({ 
                    success: true,
                    message: 'Student added successfully',
                    studentId: result.insertId 
                });
            });
        });
    } catch (error) {
        console.error('Server error:', error);
        res.status(500).json({ 
            success: false,
            message: 'Server error',
            error: error.message 
        });
    }
};


 

// Edit Student
exports.editStudent = (req, res) => {
    try {
        const studentId = req.params.id;
        const {
            rollno, class: className, section, thirdchild, name, fathername, dob,
            admissiondate, mobno, email, desc, assignclass, persentaddress, address,
            totalfees, duefees, paidfees
        } = req.body;

        const files = req.files;
        const profilephoto = files['profilephoto'] ? files['profilephoto'][0].filename : null;
        const adharcard = files['adharcard'] ? files['adharcard'][0].filename : null;

        const calculatedDueFees = duefees || (totalfees - (paidfees || 0));
        const calculatedPaidFees = paidfees || (totalfees - (duefees || 0));

        let updateQuery = `
            UPDATE students SET
            rollno=?, section=?, thirdchild=?, name=?, fathername=?, dob=?, 
            admissiondate=?, mobno=?, email=?, \`desc\`=?, assignclass=?, 
            persentaddress=?, address=?, totalfees=?, duefees=?, paidfees=?
        `;

        const values = [
            rollno, section, thirdchild, name, fathername, dob, 
            admissiondate, mobno, email, desc, assignclass, persentaddress, 
            address, totalfees, calculatedDueFees, calculatedPaidFees
        ];

        if (adharcard) {
            updateQuery += ', adharcard=?';
            values.push(adharcard);
        }
        if (profilephoto) {
            updateQuery += ', profilephoto=?';
            values.push(profilephoto);
        }

        updateQuery += ' WHERE id=?';
        values.push(studentId);

        db.query(updateQuery, values, (err, result) => {
            if (err) {
                console.error('Database error:', err);
                return res.status(500).json({ 
                    success: false,
                    message: 'Error updating student',
                    error: err.message 
                });
            }

            if (result.affectedRows === 0) {
                return res.status(404).json({ 
                    success: false,
                    message: 'Student not found' 
                });
            }

            // NEW CODE: Handle fees table operations
            const checkFeesQuery = 'SELECT id FROM fees WHERE rollno = ? AND class = ?';
            db.query(checkFeesQuery, [rollno, className], (checkErr, checkResult) => {
                if (checkErr) {
                    console.error('Error checking fees record:', checkErr);
                    return res.status(200).json({ 
                        success: true,
                        message: 'Student updated successfully (fees update skipped)' 
                    });
                }

                if (checkResult.length > 0) {
                    // Update existing fees record
                    const updateFeesQuery = `
                        UPDATE fees SET
                        name = ?, fathersname = ?, totalfees = ?, 
                        submitfees = ?, remainingfees = ?
                        WHERE rollno = ? AND class = ?
                    `;
                    db.query(updateFeesQuery, [
                        name, fathername, totalfees || 0, 
                        calculatedPaidFees || 0, calculatedDueFees || 0,
                        rollno, className
                    ], (updateFeesErr) => {
                        if (updateFeesErr) {
                            console.error('Error updating fees:', updateFeesErr);
                        }
                        res.status(200).json({ 
                            success: true,
                            message: 'Student and fees updated successfully' 
                        });
                    });
                } else {
                    // Insert new fees record
                    const insertFeesQuery = `
                        INSERT INTO fees 
                        (rollno, class, name, fathersname, totalfees, submitfees, remainingfees)
                        VALUES (?, ?, ?, ?, ?, ?, ?)
                    `;
                    db.query(insertFeesQuery, [
                        rollno, className, name, fathername, 
                        totalfees || 0, calculatedPaidFees || 0, calculatedDueFees || 0
                    ], (insertFeesErr) => {
                        if (insertFeesErr) {
                            console.error('Error inserting fees:', insertFeesErr);
                        }
                        res.status(200).json({ 
                            success: true,
                            message: 'Student updated and new fees record created' 
                        });
                    });
                }
            });
        });
    } catch (error) {
        console.error('Server error:', error);
        res.status(500).json({ 
            success: false,
            message: 'Server error',
            error: error.message 
        });
    }
};


// Get All Students
// In your studentController.js
exports.getStudents = (req, res) => {
    const classFilter = req.query.class;
    
    let query = 'SELECT id, rollno as rollNo, name, fathername as fatherName, ' +
                'mobno as contact, section FROM students';
    let values = [];
    
    if (classFilter) {
        query += ' WHERE class = ?';
        values.push(classFilter);
    }
    
    query += ' ORDER BY section, rollno';
    
    db.query(query, values, (err, results) => {
        if (err) {
            console.error('Database error:', err);
            return res.status(500).json({ 
                success: false,
                message: 'Error fetching students',
                error: err.message 
            });
        }
        
        res.status(200).json({ 
            success: true,
            data: results 
        });
    });
};




// Get Student by ID
exports.getStudentById = (req, res) => {
    const studentId = req.params.id;
    const query = 'SELECT * FROM students WHERE id = ?';
    
    db.query(query, [studentId], (err, results) => {
        if (err) {
            console.error('Database error:', err);
            return res.status(500).json({ 
                success: false,
                message: 'Error fetching student',
                error: err.message 
            });
        }
        
        if (results.length === 0) {
            return res.status(404).json({ 
                success: false,
                message: 'Student not found' 
            });
        }
        
        const student = results[0];
        // Convert file paths to URLs
        const studentWithUrls = {
            ...student,
            profilephoto: student.profilephoto ? `/uploads/students/${student.profilephoto}` : null,
            adharcard: student.adharcard ? `/uploads/students/${student.adharcard}` : null
        };
        
        res.status(200).json({ 
            success: true,
            data: studentWithUrls 
        });
    });
};

// Delete Student
exports.deleteStudent = (req, res) => {
    const studentId = req.params.id;
    const query = 'DELETE FROM students WHERE id = ?';
    
    db.query(query, [studentId], (err, result) => {
        if (err) {
            console.error('Database error:', err);
            return res.status(500).json({ 
                success: false,
                message: 'Error deleting student',
                error: err.message 
            });
        }
        
        if (result.affectedRows === 0) {
            return res.status(404).json({ 
                success: false,
                message: 'Student not found' 
            });
        }
        
        res.status(200).json({ 
            success: true,
            message: 'Student deleted successfully' 
        });
    });
};

// Get Students by Class (filter)
exports.getStudentsByClass = (req, res) => {
    const classFilter = req.query.class;
    const sectionFilter = req.query.section;
  
    let query = 'SELECT * FROM students';
    let conditions = [];
    let values = [];
  
    if (classFilter) {
        conditions.push('class = ?');
        values.push(classFilter);
    }
    
    if (sectionFilter) {
        conditions.push('section = ?');
        values.push(sectionFilter);
    }
    
    if (conditions.length > 0) {
        query += ' WHERE ' + conditions.join(' AND ');
    }
    
    query += ' ORDER BY rollno';
  
    db.query(query, values, (err, results) => {
        if (err) {
            console.error('Database error:', err);
            return res.status(500).json({ 
                success: false,
                message: 'Error fetching students',
                error: err.message 
            });
        }
        
        // Convert file paths to URLs
        const studentsWithUrls = results.map(student => ({
            ...student,
            profilephoto: student.profilephoto ? `/uploads/students/${student.profilephoto}` : null,
            adharcard: student.adharcard ? `/uploads/students/${student.adharcard}` : null
        }));
        
        res.status(200).json({ 
            success: true,
            data: studentsWithUrls 
        });
    });
};

exports.uploadReport = (req, res) => {
    const { class: studentClass, rollno, name } = req.body;

    if (!req.file) {
        return res.status(400).json({ success: false, message: 'No file uploaded' });
    }

    const marksheetPath = `/uploads/students/${req.file.filename}`;

    const query = 'INSERT INTO reports (class, rollno, name, marksheet) VALUES (?, ?, ?, ?)';
    db.query(query, [studentClass, rollno, name, marksheetPath], (err, result) => {
        if (err) {
            console.error('Error saving report:', err);
            return res.status(500).json({ success: false, message: 'Error saving report' });
        }

        res.status(200).json({ success: true, message: 'Report uploaded successfully', data: { id: result.insertId, marksheet: marksheetPath } });
    });
};


  
  // Get reports for a specific student
exports.getReportsByStudent = (req, res) => {
    const { class: studentClass, rollno } = req.params;
    const query = 'SELECT * FROM reports WHERE class = ? AND rollno = ?';

    db.query(query, [studentClass, rollno], (err, results) => {
        if (err) {
            console.error('Error fetching reports:', err);
            return res.status(500).json({ success: false, message: 'Error fetching reports' });
        }

        const updatedResults = results.map((report) => ({
            ...report,
            marksheet: report.marksheet ? report.marksheet : null,
        }));

        res.status(200).json({ success: true, data: updatedResults });
    });
};
  
  exports.deleteReport = (req, res) => {
    const reportId = req.params.id;
    const query = 'DELETE FROM reports WHERE id = ?';
  
    db.query(query, [reportId], (err, result) => {
      if (err) return res.status(500).json({ success: false, message: 'Delete failed', error: err.message });
  
      if (result.affectedRows === 0)
        return res.status(404).json({ success: false, message: 'Report not found' });
  
      res.status(200).json({ success: true, message: 'Report deleted successfully' });
    });
  };// Delete report
  exports.deleteReport = (req, res) => {
      const reportId = req.params.id;
  
      // First get file path to delete the file
      db.query('SELECT marksheet FROM reports WHERE id = ?', [reportId], (err, results) => {
          if (err || results.length === 0) {
              return res.status(404).json({ success: false, message: 'Report not found' });
          }
  
          const filePath = path.join(__dirname, '..', results[0].marksheet);
          fs.unlink(filePath, (fsErr) => {
              if (fsErr) {
                  console.warn('Error deleting file:', fsErr.message);
              }
  
              // Then delete record from DB
              db.query('DELETE FROM reports WHERE id = ?', [reportId], (err, result) => {
                  if (err) {
                      return res.status(500).json({ success: false, message: 'Failed to delete report' });
                  }
  
                  res.status(200).json({ success: true, message: 'Report deleted successfully' });
              });
          });
      });
  };

  
