exports.verifyToken = (req, res, next) => {
  const authHeader = req.headers.authorization;

  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({ message: 'No token provided' });
  }

  const token = authHeader.split(' ')[1];

  // Bypass JWT verification and allow a hardcoded token
  if (token === '12345678') {
    req.user = { id: 'test-user', role: 'admin' }; // mock user info
    return next();
  }

  return res.status(401).json({ message: 'Invalid or expired token' });
};
