import React, { Suspense, useEffect } from 'react'
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom'  // Changed to BrowserRouter
import { useSelector } from 'react-redux'

import { CSpinner, useColorModes } from '@coreui/react'
import './scss/style.scss'

// Containers
const DefaultLayout = React.lazy(() => import('./layout/DefaultLayout'))

// Pages
const Login = React.lazy(() => import('./views/pages/login/Login'))
const Home = React.lazy(() => import('./views/pages/home/home'))
const Register = React.lazy(() => import('./views/pages/register/Register'))
const Page404 = React.lazy(() => import('./views/pages/page404/Page404'))
const Page500 = React.lazy(() => import('./views/pages/page500/Page500'))

const Playground = React.lazy(() => import('./views/pages/Playground'))
const PrayerGround = React.lazy(() => import('./views/pages/PrayerGround'))
const Canteen = React.lazy(() => import('./views/pages/Canteen'))
const Transport = React.lazy(() => import('./views/pages/Transport'))
const TeachersPage = React.lazy(() => import('./views/pages/TeachersPage'))
const TopStudents = React.lazy(() => import('./views/pages/TopStudents'))
const EventsPage = React.lazy(() => import('./views/pages/EventsPage'))

const App = () => {
  const { isColorModeSet, setColorMode } = useColorModes('coreui-free-react-admin-template-theme')
  const storedTheme = useSelector((state) => state.theme)

  useEffect(() => {
    const urlParams = new URLSearchParams(window.location.href.split('?')[1])
    const theme = urlParams.get('theme') && urlParams.get('theme').match(/^[A-Za-z0-9\s]+/)[0]
    if (theme) {
      setColorMode(theme)
    }

    if (isColorModeSet()) {
      return
    }

    setColorMode(storedTheme)
  }, []) // eslint-disable-line react-hooks/exhaustive-deps

  return (
    <Router> {/* Changed to BrowserRouter */}

      <Suspense
        fallback={
          <div className="pt-3 text-center">
            <CSpinner color="primary" variant="grow" />
          </div>
        }
      >
        <Routes>
          <Route exact path="/home" name="home Page" element={<Home />} />
          <Route path="/playground" element={<Playground />} />
          <Route path="/prayer" element={<PrayerGround />} />
          <Route path="/canteen" element={<Canteen />} />
          <Route path="/transport" element={<Transport />} />
          <Route path="/teachers" element={<TeachersPage />} />
          <Route path="/students" element={<TopStudents />} />
          <Route path="/events" element={<EventsPage />} />
          <Route exact path="/login" name="Login Page" element={<Login />} />
          <Route exact path="/register" name="Register Page" element={<Register />} />
          <Route exact path="/404" name="Page 404" element={<Page404 />} />
          <Route exact path="/500" name="Page 500" element={<Page500 />} />
          <Route path="*" name="Home" element={<DefaultLayout />} />
        </Routes>
      </Suspense>
    </Router>
  )
}

export default App
