import React, { useEffect } from 'react';
import { Parallax } from 'react-parallax';
import { Fade, Zoom, Bounce } from 'react-awesome-reveal';
import { Swiper, SwiperSlide } from 'swiper/react';
import { Pagination, Navigation, Autoplay } from 'swiper/modules';
import AOS from 'aos';
import 'aos/dist/aos.css';
import 'swiper/css';
import 'swiper/css/pagination';
import 'swiper/css/navigation';
import './Playground.css';

// Sample images - replace with your actual images
import playgroundMain from '../../assets/images/playground-main.jpg';
import cricket from '../../assets/images/cricket.avif';
import football from '../../assets/images/football.jpg';
import basketball from '../../assets/images/basketball.jpg';
import kabaddi from '../../assets/images/kabaddi.jpg';
import running from '../../assets/images/running.jpg';
import playground1 from '../../assets/images/playground1.webp';
import playground2 from '../../assets/images/playground2.webp';
import playground3 from '../../assets/images/playground3.webp';

function Playground() {
  useEffect(() => {
    AOS.init({ duration: 1200 });
  }, []);

  const sportsFacilities = [
    { name: 'Cricket', img: cricket, desc: 'Professional cricket pitch with practice nets' },
    { name: 'Football', img: football, desc: 'Full-size football field with artificial turf' },
    { name: 'Basketball', img: basketball, desc: 'Multiple courts with professional flooring' },
    { name: 'Kabaddi', img: kabaddi, desc: 'Dedicated kabaddi court with safety mats' },
    { name: 'Athletics', img: running, desc: '200m running track and field events area' },
  ];

  const testimonials = [
    { name: 'Rahul Sharma', role: 'Cricket Team Captain', quote: 'The playground facilities helped me represent our district in tournaments.' },
    { name: 'Priya Patel', role: 'Basketball Player', quote: 'Our basketball court is better than many college facilities I\'ve seen.' },
    { name: 'Coach Singh', role: 'Sports Teacher', quote: 'The variety of facilities allows us to train students in multiple disciplines.' },
  ];

  return (
    <div className="playground-page">
      {/* Hero Section with Parallax */}
      <Parallax bgImage={playgroundMain} strength={500} className="parallax-hero">
        <div className="hero-overlay">
          <Fade direction="down" duration={1500} triggerOnce>
            <h1>Our World-Class Playground</h1>
            <p>Where champions are made and memories are created</p>
          </Fade>
        </div>
      </Parallax>

      {/* Introduction Section */}
      <section className="section intro-section" data-aos="fade-up">
        <div className="container">
          <Zoom triggerOnce>
            <h2>More Than Just a Playground</h2>
          </Zoom>
          <div className="intro-content">
            <div className="intro-text">
              <Fade cascade damping={0.1} triggerOnce>
                <p>Our 5-acre sports complex is designed to nurture athletic talent while promoting physical fitness for all students. With professional-grade facilities and certified coaches, we provide an environment where students can excel in their chosen sports.</p>
                <p>Daily physical education classes, inter-house competitions, and professional coaching sessions ensure that every student finds their athletic passion.</p>
                <p>The playground isn't just about sports - it's where teamwork, discipline, and leadership skills are developed through joyful activities.</p>
              </Fade>
            </div>
            <div className="intro-stats">
              <Bounce cascade triggerOnce>
                <div className="stat-item">
                  <h3>5+</h3>
                  <p>Professional Coaches</p>
                </div>
                <div className="stat-item">
                  <h3>12</h3>
                  <p>Sports Disciplines</p>
                </div>
                <div className="stat-item">
                  <h3>50+</h3>
                  <p>Tournaments Yearly</p>
                </div>
              </Bounce>
            </div>
          </div>
        </div>
      </section>

      {/* Sports Facilities Gallery */}
      <section className="section facilities-section">
        <div className="container">
          <h2 data-aos="fade-up">Our Sports Facilities</h2>
          <Swiper
            modules={[Pagination, Navigation, Autoplay]}
            spaceBetween={30}
            slidesPerView={1}
            pagination={{ clickable: true }}
            navigation
            autoplay={{ delay: 5000 }}
            breakpoints={{
              768: { slidesPerView: 2 },
              1024: { slidesPerView: 3 }
            }}
            className="facilities-slider"
          >
            {sportsFacilities.map((sport, index) => (
              <SwiperSlide key={index} data-aos="zoom-in" data-aos-delay={index * 100}>
                <div className="sport-card">
                  <div className="sport-img-container">
                    <img src={sport.img} alt={sport.name} />
                    <div className="sport-overlay">
                      <h3>{sport.name}</h3>
                    </div>
                  </div>
                  <p>{sport.desc}</p>
                </div>
              </SwiperSlide>
            ))}
          </Swiper>
        </div>
      </section>

      {/* Playground Tour Section */}
      <section className="section tour-section">
        <div className="container">
          <h2 data-aos="fade-up">Virtual Playground Tour</h2>
          <div className="tour-gallery">
            <Fade direction="left" triggerOnce>
              <div className="tour-card main-card">
                <img src={playground1} alt="Playground view" />
                <div className="tour-info">
                  <h3>Main Field</h3>
                  <p>Multi-purpose field for football, athletics and school events</p>
                </div>
              </div>
            </Fade>
            <div className="secondary-cards">
              <Fade direction="up" triggerOnce>
                <div className="tour-card">
                  <img src={playground2} alt="Basketball courts" />
                  <div className="tour-info">
                    <h3>Courts Complex</h3>
                    <p>Basketball, volleyball and badminton courts</p>
                  </div>
                </div>
              </Fade>
              <Fade direction="up" triggerOnce delay={200}>
                <div className="tour-card">
                  <img src={playground3} alt="Students playing" />
                  <div className="tour-info">
                    <h3>Activity Zone</h3>
                    <p>Space for yoga, gymnastics and outdoor classes</p>
                  </div>
                </div>
              </Fade>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section className="section testimonials-section">
        <div className="container">
          <h2 data-aos="fade-up">What People Say</h2>
          <Swiper
            modules={[Pagination, Autoplay]}
            spaceBetween={30}
            slidesPerView={1}
            pagination={{ clickable: true }}
            autoplay={{ delay: 6000 }}
            className="testimonials-slider"
          >
            {testimonials.map((testimonial, index) => (
              <SwiperSlide key={index}>
                <Fade triggerOnce>
                  <div className="testimonial-card">
                    <div className="testimonial-content">
                      <p>"{testimonial.quote}"</p>
                      <div className="testimonial-author">
                        <h4>{testimonial.name}</h4>
                        <span>{testimonial.role}</span>
                      </div>
                    </div>
                  </div>
                </Fade>
              </SwiperSlide>
            ))}
          </Swiper>
        </div>
      </section>

      {/* CTA Section */}
      <section className="section cta-section">
        <Parallax bgImage={running} strength={300}>
          <div className="cta-overlay">
            <div className="container" data-aos="zoom-in">
              <h2>Ready to Join Our Sports Programs?</h2>
              <p>Contact our sports department to learn about training schedules and team tryouts</p>
              <button className="cta-button">Contact Sports Coach</button>
            </div>
          </div>
        </Parallax>
      </section>
    </div>
  );
}

export default Playground;