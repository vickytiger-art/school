import React, { useEffect } from 'react';
import { Parallax } from 'react-parallax';
import { Fade, Zoom, Bounce } from 'react-awesome-reveal';
import { Swiper, SwiperSlide } from 'swiper/react';
import { Pagination, Navigation, Autoplay } from 'swiper/modules';
import AOS from 'aos';
import 'aos/dist/aos.css';
import 'swiper/css';
import 'swiper/css/pagination';
import 'swiper/css/navigation';
import './Canteen.css';

// Sample images - replace with your actual images
import canteenHero from '../../assets/images/canteen-hero.jpg';
import meal1 from '../../assets/images/meal1.jpg';
import meal2 from '../../assets/images/meal2.jpg';
import meal3 from '../../assets/images/meal3.webp';
import snack1 from '../../assets/images/snack1.webp';
import snack2 from '../../assets/images/snack2.webp';
import diningArea from '../../assets/images/dining-area.jpg';
import kitchen from '../../assets/images/kitchen.jpg';

function Canteen() {
  useEffect(() => {
    AOS.init({ duration: 1200 });
  }, []);

  const menuItems = [
    { name: 'Healthy Lunch', img: meal1, desc: 'Balanced meals with proteins, carbs, and veggies', price: '$3.50' },
    { name: 'Fresh Salads', img: meal2, desc: 'Daily prepared with seasonal ingredients', price: '$2.75' },
    { name: 'Hot Meals', img: meal3, desc: 'Warm, nutritious options every day', price: '$3.25' },
    { name: 'Fruit Snacks', img: snack1, desc: 'Assorted fresh fruits and yogurt', price: '$1.50' },
    { name: 'Baked Goods', img: snack2, desc: 'Homemade muffins and cookies', price: '$1.25' },
  ];

  const features = [
    { icon: '🥗', title: 'Nutritionist Approved', desc: 'All meals meet nutritional guidelines' },
    { icon: '🧼', title: 'Hygienic Kitchen', desc: 'Daily cleaning and food safety checks' },
    { icon: '🌱', title: 'Vegetarian Options', desc: 'Delicious plant-based meals available' },
    { icon: '💰', title: 'Affordable Prices', desc: 'Budget-friendly for all students' },
  ];

  const testimonials = [
    { name: 'Rahul Patel', role: 'Grade 10 Student', quote: 'The canteen food gives me energy for my afternoon classes!' },
    { name: 'Mrs. Sharma', role: 'Parent', quote: 'I appreciate the healthy options available for my children.' },
    { name: 'Chef Arjun', role: 'Head Cook', quote: 'We take pride in preparing fresh meals daily with local ingredients.' },
  ];

  return (
    <div className="canteen-page">
      {/* Hero Section with Parallax */}
      <Parallax bgImage={canteenHero} strength={500} className="parallax-hero">
        <div className="hero-overlay">
          <Fade direction="down" duration={1500} triggerOnce>
            <h1>Our School Canteen</h1>
            <p>Where healthy meals meet happy students</p>
          </Fade>
        </div>
      </Parallax>

      {/* Introduction Section */}
      <section className="section intro-section" data-aos="fade-up">
        <div className="container">
          <Zoom triggerOnce>
            <h2>Fresh & Nutritious Meals</h2>
            <div className="divider"></div>
          </Zoom>
          <div className="intro-content">
            <div className="intro-text">
              <Fade cascade damping={0.1} triggerOnce>
                <p>Our school canteen is more than just a place to eat - it's a vital part of our students' daily routine that fuels both body and mind. We believe that healthy eating habits contribute to better learning and overall well-being.</p>
                <p>Our menu is carefully designed by nutritionists to provide balanced meals that give students the energy they need throughout the school day. We prioritize fresh, locally-sourced ingredients and prepare everything in our hygienic kitchen.</p>
                <p>From hearty meals to wholesome snacks, we offer options to suit all tastes while maintaining high nutritional standards at affordable prices.</p>
              </Fade>
            </div>
            <div className="intro-image">
              <Zoom triggerOnce>
                <img src={diningArea} alt="Students dining" />
              </Zoom>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="section features-section">
        <div className="container">
          <h2 data-aos="fade-up">Why Our Canteen Stands Out</h2>
          <div className="features-grid">
            {features.map((feature, index) => (
              <Fade key={index} direction="up" delay={index * 100} triggerOnce>
                <div className="feature-card">
                  <div className="feature-icon">{feature.icon}</div>
                  <h3>{feature.title}</h3>
                  <p>{feature.desc}</p>
                </div>
              </Fade>
            ))}
          </div>
        </div>
      </section>

      {/* Menu Section */}
      <section className="section menu-section">
        <div className="container">
          <h2 data-aos="fade-up">Our Weekly Menu</h2>
          <Swiper
            modules={[Pagination, Navigation, Autoplay]}
            spaceBetween={30}
            slidesPerView={1}
            pagination={{ clickable: true }}
            navigation
            autoplay={{ delay: 5000 }}
            breakpoints={{
              768: { slidesPerView: 2 },
              1024: { slidesPerView: 3 }
            }}
            className="menu-slider"
          >
            {menuItems.map((item, index) => (
              <SwiperSlide key={index} data-aos="zoom-in" data-aos-delay={index * 100}>
                <div className="menu-card">
                  <div className="menu-img-container">
                    <img src={item.img} alt={item.name} />
                    <div className="price-tag">{item.price}</div>
                  </div>
                  <div className="menu-info">
                    <h3>{item.name}</h3>
                    <p>{item.desc}</p>
                  </div>
                </div>
              </SwiperSlide>
            ))}
          </Swiper>
        </div>
      </section>

      {/* Kitchen Tour Section */}
      <section className="section tour-section">
        <div className="container">
          <h2 data-aos="fade-up">Behind the Scenes</h2>
          <div className="tour-content">
            <Fade direction="left" triggerOnce>
              <div className="tour-text">
                <h3>Our Hygienic Kitchen</h3>
                <p>We maintain the highest standards of cleanliness and food safety in our kitchen. Our staff undergoes regular training in food handling and hygiene practices.</p>
                <ul>
                  <li>Daily deep cleaning schedule</li>
                  <li>Fresh ingredients prepared each morning</li>
                  <li>Regular health inspections</li>
                  <li>Proper food storage and handling</li>
                </ul>
              </div>
            </Fade>
            <Fade direction="right" triggerOnce>
              <div className="tour-image">
                <img src={kitchen} alt="School kitchen" />
              </div>
            </Fade>
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section className="section testimonials-section">
        <div className="container">
          <h2 data-aos="fade-up">What People Say</h2>
          <Swiper
            modules={[Pagination, Autoplay]}
            spaceBetween={30}
            slidesPerView={1}
            pagination={{ clickable: true }}
            autoplay={{ delay: 6000 }}
            className="testimonials-slider"
          >
            {testimonials.map((testimonial, index) => (
              <SwiperSlide key={index}>
                <Fade triggerOnce>
                  <div className="testimonial-card">
                    <div className="quote-icon">"</div>
                    <div className="testimonial-content">
                      <p>{testimonial.quote}</p>
                      <div className="testimonial-author">
                        <h4>{testimonial.name}</h4>
                        <span>{testimonial.role}</span>
                      </div>
                    </div>
                  </div>
                </Fade>
              </SwiperSlide>
            ))}
          </Swiper>
        </div>
      </section>

      {/* CTA Section */}
      <section className="section cta-section">
        <Parallax bgImage={meal1} strength={300}>
          <div className="cta-overlay">
            <div className="container" data-aos="zoom-in">
              <Fade cascade triggerOnce>
                <h2>Have Special Dietary Needs?</h2>
                <p>Contact our canteen staff to discuss meal options for students with allergies or special dietary requirements</p>
                <button className="cta-button">Contact Canteen Staff</button>
              </Fade>
            </div>
          </div>
        </Parallax>
      </section>
    </div>
  );
}

export default Canteen;