import React, { useEffect } from 'react';
import { Parallax } from 'react-parallax';
import { Fade, Zoom, Bounce } from 'react-awesome-reveal';
import { Swiper, SwiperSlide } from 'swiper/react';
import { Pagination, Navigation, Autoplay } from 'swiper/modules';
import AOS from 'aos';
import 'aos/dist/aos.css';
import 'swiper/css';
import 'swiper/css/pagination';
import 'swiper/css/navigation';
import './Transport.css';

// Sample images - replace with your actual images
import transportHero from '../../assets/images/transport-hero.jpg';
import bus1 from '../../assets/images/bus1.jpg';
import bus2 from '../../assets/images/bus2.avif';
import bus3 from '../../assets/images/bus3.jpg';
import safety1 from '../../assets/images/safety1.jpg';
import safety2 from '../../assets/images/safety2.jpg';
import routeMap from '../../assets/images/route-map.jpg';
import driver from '../../assets/images/route-map.jpg';

function Transport() {
  useEffect(() => {
    AOS.init({ duration: 1200 });
  }, []);

  const features = [
    { icon: '🚌', title: 'Modern Fleet', desc: 'Air-conditioned buses with seat belts' },
    { icon: '📍', title: 'GPS Tracking', desc: 'Real-time tracking for parents' },
    { icon: '👩‍✈️', title: 'Trained Staff', desc: 'Experienced drivers and attendants' },
    { icon: '⏱️', title: 'Punctual Service', desc: 'Strict adherence to schedules' },
  ];

  const safetyFeatures = [
    { icon: '🛡️', title: 'First Aid Kits', desc: 'Available on all buses' },
    { icon: '📱', title: 'Emergency Contact', desc: 'Direct line to school admin' },
    { icon: '👀', title: 'CCTV Cameras', desc: 'Monitoring for student safety' },
    { icon: '🚨', title: 'Speed Governors', desc: 'Ensuring safe driving speeds' },
  ];

  const testimonials = [
    { name: 'Mrs. Sharma', role: 'Parent', quote: 'The GPS tracking gives me peace of mind knowing exactly when my child reaches school.' },
    { name: 'Rahul K.', role: 'Grade 9 Student', quote: 'Our bus driver is so friendly and always makes sure were safe.' },
    { name: 'Driver Singh', role: 'Transport Staff', quote: 'We treat every student like our own children during the commute.' },
  ];

  return (
    <div className="transport-page">
      {/* Hero Section with Parallax */}
      <Parallax bgImage={transportHero} strength={500} className="parallax-hero">
        <div className="hero-overlay">
          <Fade direction="down" duration={1500} triggerOnce>
            <h1>Safe & Reliable School Transport</h1>
            <p>Your child's safety is our top priority</p>
          </Fade>
        </div>
      </Parallax>

      {/* Introduction Section */}
      <section className="section intro-section" data-aos="fade-up">
        <div className="container">
          <Zoom triggerOnce>
            <h2>Our Transport Network</h2>
            <div className="divider"></div>
          </Zoom>
          <div className="intro-content">
            <div className="intro-text">
              <Fade cascade damping={0.1} triggerOnce>
                <p>Our comprehensive school transport system ensures safe, comfortable, and reliable transportation for students across the city. With carefully planned routes and strict safety protocols, we make the daily commute stress-free for both students and parents.</p>
                <p>Our fleet of modern, well-maintained buses covers all major residential areas, with convenient pickup and drop-off points. Each vehicle is equipped with advanced safety features and real-time tracking technology.</p>
                <p>We understand that transportation is an extension of the school experience, which is why we maintain the same standards of care and supervision as we do within our campus.</p>
              </Fade>
            </div>
            <div className="intro-image">
              <Zoom triggerOnce>
                <img src={routeMap} alt="Transport route map" />
              </Zoom>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="section features-section">
        <div className="container">
          <h2 data-aos="fade-up">Our Transport Features</h2>
          <div className="features-grid">
            {features.map((feature, index) => (
              <Fade key={index} direction="up" delay={index * 100} triggerOnce>
                <div className="feature-card">
                  <div className="feature-icon">{feature.icon}</div>
                  <h3>{feature.title}</h3>
                  <p>{feature.desc}</p>
                </div>
              </Fade>
            ))}
          </div>
        </div>
      </section>

      {/* Fleet Gallery Section */}
      <section className="section fleet-section">
        <div className="container">
          <h2 data-aos="fade-up">Our Fleet</h2>
          <Swiper
            modules={[Pagination, Navigation, Autoplay]}
            spaceBetween={30}
            slidesPerView={1}
            pagination={{ clickable: true }}
            navigation
            autoplay={{ delay: 5000 }}
            breakpoints={{
              768: { slidesPerView: 2 },
              1024: { slidesPerView: 3 }
            }}
            className="fleet-slider"
          >
            <SwiperSlide>
              <div className="fleet-card">
                <img src={bus1} alt="School bus" />
                <div className="fleet-overlay">
                  <h3>Standard Bus</h3>
                  <p>Capacity: 40 students</p>
                </div>
              </div>
            </SwiperSlide>
            <SwiperSlide>
              <div className="fleet-card">
                <img src={bus2} alt="Mini bus" />
                <div className="fleet-overlay">
                  <h3>Mini Bus</h3>
                  <p>Capacity: 25 students</p>
                </div>
              </div>
            </SwiperSlide>
            <SwiperSlide>
              <div className="fleet-card">
                <img src={bus3} alt="Luxury bus" />
                <div className="fleet-overlay">
                  <h3>Premium Bus</h3>
                  <p>With individual AC vents</p>
                </div>
              </div>
            </SwiperSlide>
          </Swiper>
        </div>
      </section>

      {/* Safety Section */}
      <section className="section safety-section">
        <div className="container">
          <h2 data-aos="fade-up">Safety First</h2>
          <div className="safety-content">
            <Fade direction="left" triggerOnce>
              <div className="safety-features">
                <h3>Our Safety Measures</h3>
                <div className="safety-grid">
                  {safetyFeatures.map((feature, index) => (
                    <div key={index} className="safety-card">
                      <div className="safety-icon">{feature.icon}</div>
                      <div>
                        <h4>{feature.title}</h4>
                        <p>{feature.desc}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </Fade>
            <Fade direction="right" triggerOnce>
              <div className="safety-image">
                <img src={safety1} alt="Safety features" />
              </div>
            </Fade>
          </div>
        </div>
      </section>

      {/* Staff Section */}
      <section className="section staff-section">
        <div className="container">
          <div className="staff-content">
            <Fade direction="left" triggerOnce>
              <div className="staff-image">
                <img src={driver} alt="Bus driver" />
              </div>
            </Fade>
            <Fade direction="right" triggerOnce>
              <div className="staff-text">
                <h3>Our Professional Staff</h3>
                <p>All our drivers undergo rigorous training including:</p>
                <ul>
                  <li>Defensive driving certification</li>
                  <li>Child psychology workshops</li>
                  <li>Emergency response training</li>
                  <li>Regular health check-ups</li>
                </ul>
                <p>Each bus has a trained attendant to assist students during boarding and disembarking.</p>
              </div>
            </Fade>
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section className="section testimonials-section">
        <div className="container">
          <h2 data-aos="fade-up">What Parents Say</h2>
          <Swiper
            modules={[Pagination, Autoplay]}
            spaceBetween={30}
            slidesPerView={1}
            pagination={{ clickable: true }}
            autoplay={{ delay: 6000 }}
            className="testimonials-slider"
          >
            {testimonials.map((testimonial, index) => (
              <SwiperSlide key={index}>
                <Fade triggerOnce>
                  <div className="testimonial-card">
                    <div className="quote-icon">"</div>
                    <div className="testimonial-content">
                      <p>{testimonial.quote}</p>
                      <div className="testimonial-author">
                        <h4>{testimonial.name}</h4>
                        <span>{testimonial.role}</span>
                      </div>
                    </div>
                  </div>
                </Fade>
              </SwiperSlide>
            ))}
          </Swiper>
        </div>
      </section>

      {/* CTA Section */}
      <section className="section cta-section">
        <Parallax bgImage={safety2} strength={300}>
          <div className="cta-overlay">
            <div className="container" data-aos="zoom-in">
              <Fade cascade triggerOnce>
                <h2>Need Transport Services?</h2>
                <p>Contact our transport coordinator to check route availability and register your child</p>
                <button className="cta-button">Enquire Now</button>
              </Fade>
            </div>
          </div>
        </Parallax>
      </section>
    </div>
  );
}

export default Transport;