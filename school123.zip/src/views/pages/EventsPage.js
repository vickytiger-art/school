import React, { useEffect } from 'react';
import { Fade, Zoom, Bounce } from 'react-awesome-reveal';
import AOS from 'aos';
import 'aos/dist/aos.css';
import './EventsPage.css';

// Sample images - replace with your actual images
import farewellImg from '../../assets/images/farewell.jpg';
import annualImg from '../../assets/images/annual.webp';
import republicImg from '../../assets/images/republic.jpg';
import sportsImg from '../../assets/images/sports.jpg';
import scienceImg from '../../assets/images/science.jpg';
import culturalImg from '../../assets/images/cultural.webp';
// import eventsHero from './assets/events-hero.jpg';

function EventsPage() {
  useEffect(() => {
    AOS.init({ duration: 1200 });
  }, []);

  const eventCategories = [
    {
      title: "Farewell",
      events: [
        {
          name: "Farewell 2024",
          image: farewellImg,
          date: "May 15, 2024",
          description: "Celebrating our graduating class with memorable performances and awards",
          highlights: ["Student speeches", "Award ceremony", "Cultural performances"]
        }
      ]
    },
    {
      title: "Annual Function",
      events: [
        {
          name: "Annual Day Celebration",
          image: annualImg,
          date: "December 10, 2023",
          description: "Our grand showcase of student talent and achievements",
          highlights: ["Dance performances", "Drama presentation", "Prize distribution"]
        }
      ]
    },
    {
      title: "National Events",
      events: [
        {
          name: "Republic Day",
          image: republicImg,
          date: "January 26, 2024",
          description: "Patriotic celebrations honoring our nation's constitution",
          highlights: ["Flag hoisting", "Cultural parade", "Patriotic songs"]
        }
      ]
    },
    {
      title: "Sports Events",
      events: [
        {
          name: "Annual Sports Day",
          image: sportsImg,
          date: "February 20, 2024",
          description: "Showcasing athletic talent and sportsmanship",
          highlights: ["Track events", "Team competitions", "Prize ceremony"]
        }
      ]
    },
    {
      title: "Academic Events",
      events: [
        {
          name: "Science Fair",
          image: scienceImg,
          date: "November 5, 2023",
          description: "Exhibition of innovative student projects",
          highlights: ["Project displays", "Judging rounds", "Demonstrations"]
        }
      ]
    },
    {
      title: "Cultural Events",
      events: [
        {
          name: "Inter-School Competition",
          image: culturalImg,
          date: "September 15, 2023",
          description: "Cultural exchange with neighboring schools",
          highlights: ["Music competition", "Dance battle", "Art exhibition"]
        }
      ]
    }
  ];

  return (
    <div className="events-page">
      {/* Hero Section */}
      <div className="events-hero">
        <div className="hero-overlay">
          <Fade direction="down" duration={1500} triggerOnce>
            <h1>School Events Gallery</h1>
            <p>Celebrating our vibrant school community</p>
          </Fade>
        </div>
      </div>

      {/* Events Grid */}
      <section className="events-section">
        <div className="container">
          <Zoom triggerOnce>
            <h2>Our Memorable Events</h2>
            <div className="divider"></div>
          </Zoom>

          {eventCategories.map((category, catIndex) => (
            <div className="event-category" key={catIndex} data-aos="fade-up">
              <Fade direction="left" triggerOnce>
                <h3 className="category-title">{category.title}</h3>
              </Fade>
              <div className="events-grid">
                {category.events.map((event, eventIndex) => (
                  <Fade key={eventIndex} direction="up" delay={eventIndex * 100} triggerOnce>
                    <div className="event-card">
                      <div className="event-image-container">
                        <img src={event.image} alt={event.name} className="event-image" />
                        <div className="event-date">{event.date}</div>
                      </div>
                      <div className="event-details">
                        <h4>{event.name}</h4>
                        <p className="event-description">{event.description}</p>
                        <div className="event-highlights">
                          {event.highlights.map((highlight, hiIndex) => (
                            <Bounce key={hiIndex} delay={hiIndex * 150} triggerOnce>
                              <div className="highlight-item">
                                <span className="highlight-icon">✓</span>
                                <span>{highlight}</span>
                              </div>
                            </Bounce>
                          ))}
                        </div>
                      </div>
                    </div>
                  </Fade>
                ))}
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* CTA Section */}
      <section className="events-cta" data-aos="fade-up">
        <div className="container">
          <Fade cascade triggerOnce>
            <h2>Stay Updated on Upcoming Events</h2>
            <p>Follow our school calendar for the latest event schedules and announcements</p>
            <button className="cta-button">View Event Calendar</button>
          </Fade>
        </div>
      </section>
    </div>
  );
}

export default EventsPage;