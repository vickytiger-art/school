import React, { useEffect } from 'react';
import { Parallax } from 'react-parallax';
import { Fade, Zoom, Bounce } from 'react-awesome-reveal';
import { Swiper, SwiperSlide } from 'swiper/react';
import { Pagination, Autoplay } from 'swiper/modules';
import AOS from 'aos';
import 'aos/dist/aos.css';
import 'swiper/css';
import 'swiper/css/pagination';
import './PrayerGround.css';

// Sample images - replace with your actual images
import prayerHero from '../../assets/images/prayer-hero.jpg';
import prayer1 from '../../assets/images/prayer1.avif';
import prayer2 from '../../assets/images/prayer2.webp';
import prayer3 from '../../assets/images/prayer3.jpg';
import assembly from '../../assets/images/assembly.avif';
import meditation from '../../assets/images/meditation.webp';

function PrayerGround() {
  useEffect(() => {
    AOS.init({ duration: 1200 });
  }, []);

  const features = [
    { icon: '🙏', title: 'Morning Assembly', desc: 'Daily gatherings for prayer and moral teachings' },
    { icon: '🕊️', title: 'Peaceful Environment', desc: 'Serene space designed for reflection and spirituality' },
    { icon: '📿', title: 'Multi-Faith Respect', desc: 'Inclusive space honoring all religious traditions' },
    { icon: '📖', title: 'Scripture Readings', desc: 'Regular readings from various holy books' },
  ];

  const testimonials = [
    { name: 'Priya Sharma', role: 'Class 12 Student', quote: 'The morning prayers ground me and prepare me for the day ahead.' },
    { name: 'Father Thomas', role: 'School Chaplain', quote: 'This sacred space nurtures the spiritual growth of our students.' },
    { name: 'Mrs. Khan', role: 'Parent', quote: 'I appreciate how the school cultivates both knowledge and values.' },
  ];

  return (
    <div className="prayer-page">
      {/* Hero Section with Parallax */}
      <Parallax bgImage={prayerHero} strength={500} className="parallax-hero">
        <div className="hero-overlay">
          <Fade direction="down" duration={1500} triggerOnce>
            <h1>Sacred Prayer Ground</h1>
            <p>A sanctuary for spiritual growth and moral development</p>
          </Fade>
        </div>
      </Parallax>

      {/* Introduction Section */}
      <section className="section intro-section" data-aos="fade-up">
        <div className="container">
          <Zoom triggerOnce>
            <h2>Our Spiritual Heart</h2>
            <div className="divider"></div>
          </Zoom>
          <div className="intro-content">
            <div className="intro-text">
              <Fade cascade damping={0.1} triggerOnce>
                <p>Nestled in the heart of our campus, the prayer ground serves as the spiritual center of our school community. This carefully designed open-air sanctuary provides a tranquil space for students to connect with the divine, reflect on moral values, and find inner peace.</p>
                <p>Every morning begins here with assembly, where students from all faiths gather to pray, meditate, and listen to uplifting messages that guide their character development.</p>
                <p>The circular design symbolizes unity and equality, with seating arranged to foster community while respecting individual contemplation.</p>
              </Fade>
            </div>
            <div className="intro-image">
              <Zoom triggerOnce>
                <img src={assembly} alt="Morning assembly" />
              </Zoom>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="section features-section">
        <div className="container">
          <h2 data-aos="fade-up">Sacred Features</h2>
          <div className="features-grid">
            {features.map((feature, index) => (
              <Fade key={index} direction="up" delay={index * 100} triggerOnce>
                <div className="feature-card">
                  <div className="feature-icon">{feature.icon}</div>
                  <h3>{feature.title}</h3>
                  <p>{feature.desc}</p>
                </div>
              </Fade>
            ))}
          </div>
        </div>
      </section>

      {/* Gallery Section */}
      <section className="section gallery-section">
        <div className="container">
          <h2 data-aos="fade-up">Moments of Reflection</h2>
          <Swiper
            modules={[Pagination, Autoplay]}
            spaceBetween={30}
            slidesPerView={1}
            pagination={{ clickable: true }}
            autoplay={{ delay: 5000 }}
            breakpoints={{
              768: { slidesPerView: 2 },
              1024: { slidesPerView: 3 }
            }}
            className="prayer-slider"
          >
            <SwiperSlide>
              <div className="gallery-card">
                <img src={prayer1} alt="Students praying" />
                <div className="gallery-overlay">
                  <p>Morning Prayer Gathering</p>
                </div>
              </div>
            </SwiperSlide>
            <SwiperSlide>
              <div className="gallery-card">
                <img src={prayer2} alt="Meditation session" />
                <div className="gallery-overlay">
                  <p>Guided Meditation</p>
                </div>
              </div>
            </SwiperSlide>
            <SwiperSlide>
              <div className="gallery-card">
                <img src={prayer3} alt="Candle lighting" />
                <div className="gallery-overlay">
                  <p>Special Ceremonies</p>
                </div>
              </div>
            </SwiperSlide>
            <SwiperSlide>
              <div className="gallery-card">
                <img src={meditation} alt="Quiet reflection" />
                <div className="gallery-overlay">
                  <p>Personal Reflection</p>
                </div>
              </div>
            </SwiperSlide>
          </Swiper>
        </div>
      </section>

      {/* Testimonials Section */}
      <section className="section testimonials-section">
        <div className="container">
          <h2 data-aos="fade-up">Voices of Faith</h2>
          <Swiper
            modules={[Pagination, Autoplay]}
            spaceBetween={30}
            slidesPerView={1}
            pagination={{ clickable: true }}
            autoplay={{ delay: 6000 }}
            className="testimonials-slider"
          >
            {testimonials.map((testimonial, index) => (
              <SwiperSlide key={index}>
                <Fade triggerOnce>
                  <div className="testimonial-card">
                    <div className="quote-icon">"</div>
                    <div className="testimonial-content">
                      <p>{testimonial.quote}</p>
                      <div className="testimonial-author">
                        <h4>{testimonial.name}</h4>
                        <span>{testimonial.role}</span>
                      </div>
                    </div>
                  </div>
                </Fade>
              </SwiperSlide>
            ))}
          </Swiper>
        </div>
      </section>

      {/* Meditation Section */}
      <section className="section meditation-section">
        <Parallax bgImage={meditation} strength={300}>
          <div className="meditation-overlay">
            <div className="container" data-aos="fade-up">
              <Fade cascade triggerOnce>
                <h2>Find Your Center</h2>
                <p>Our prayer ground is open throughout the day for students seeking quiet reflection or personal prayer.</p>
                <button className="meditation-button">Learn About Our Values Program</button>
              </Fade>
            </div>
          </div>
        </Parallax>
      </section>
    </div>
  );
}

export default PrayerGround;