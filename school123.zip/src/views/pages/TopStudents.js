import React, { useEffect } from 'react';
import { Fade, Zoom, Bounce } from 'react-awesome-reveal';
import AOS from 'aos';
import 'aos/dist/aos.css';
import './TopStudents.css';

// Sample images - replace with your actual images
import student1 from '../../assets/images/teacher1.webp';
import student2 from '../../assets/images/teacher2.jpg';
import student3 from '../../assets/images/teacher2.jpg';
// import studentsBg from './assets/students-bg.jpg';
import achievementIcon from '../../assets/images/teacher2.jpg';

function TopStudents() {
  useEffect(() => {
    AOS.init({ duration: 1200 });
  }, []);

  const students = [
    { 
      name: 'Ananya Sharma', 
      class: '10th A', 
      photo: student1,
      achievements: ['School Topper 2023', 'Math Olympiad Gold', 'Debate Champion'],
      quote: "Learning is my superpower!"
    },
    { 
      name: 'Rahul Verma', 
      class: '9th B', 
      photo: student2,
      achievements: ['Science Fair Winner', 'Sports Captain', 'Best in Coding'],
      quote: "I turn challenges into opportunities"
    },
    { 
      name: 'Sneha Patel', 
      class: '8th A', 
      photo: student3,
      achievements: ['Art Competition Winner', 'Young Author Award', 'Music Prodigy'],
      quote: "Creativity knows no bounds"
    },
  ];

  return (
    <div className="students-page">
      {/* Hero Section */}
      <div className="students-hero">
        <div className="hero-overlay">
          <Fade direction="down" duration={1500} triggerOnce>
            <h1>Our Shining Stars</h1>
            <p>Celebrating excellence and achievement</p>
          </Fade>
        </div>
      </div>

      {/* Students Grid */}
      <section className="students-section">
        <div className="container">
          <Zoom triggerOnce>
            <h2>Top Performers of the Year</h2>
            <div className="divider"></div>
          </Zoom>
          
          <div className="student-cards">
            {students.map((student, index) => (
              <Fade key={index} direction="up" delay={index * 100} triggerOnce>
                <div className="student-card" data-aos="zoom-in">
                  <div className="ribbon">Top Achiever</div>
                  <img src={student.photo} alt={student.name} className="student-photo" />
                  <div className="student-info">
                    <h3>{student.name}</h3>
                    <p className="class">{student.class}</p>
                    <div className="achievements">
                      {student.achievements.map((item, i) => (
                        <Bounce key={i} delay={i * 150} triggerOnce>
                          <div className="achievement-item">
                            <img src={achievementIcon} alt="achievement" className="achievement-icon" />
                            <span>{item}</span>
                          </div>
                        </Bounce>
                      ))}
                    </div>
                    <div className="quote">
                      <p>"{student.quote}"</p>
                    </div>
                  </div>
                </div>
              </Fade>
            ))}
          </div>
        </div>
      </section>

      {/* Celebration Section */}
      <section className="celebration-section" data-aos="fade-up">
        <div className="container">
          <h2>Recognizing Excellence</h2>
          <div className="celebration-content">
            <Fade cascade damping={0.1} triggerOnce>
              <p>We believe in celebrating not just academic success but all forms of achievement that demonstrate dedication, creativity, and character.</p>
              <p>Our top students are selected based on their overall performance, leadership qualities, and contributions to school community.</p>
            </Fade>
          </div>
        </div>
      </section>
    </div>
  );
}

export default TopStudents;