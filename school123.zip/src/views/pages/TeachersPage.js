import React, { useEffect } from 'react';
import { Fade, Zoom } from 'react-awesome-reveal';
import AOS from 'aos';
import 'aos/dist/aos.css';
import './TeachersPage.css';

// Sample images - replace with your actual images
import teacher1 from '../../assets/images/teacher1.webp';
import teacher2 from '../../assets/images/teacher2.jpg';
import teacher3 from '../../assets/images/teacher3.jpg';
import teacherBg from '../../assets/images/teacher-bg.jpg';

function TeachersPage() {
  useEffect(() => {
    AOS.init({ duration: 1200 });
  }, []);

  const teachers = [
    { 
      name: 'Mrs. Meera Sharma', 
      subject: 'Mathematics', 
      photo: teacher1,
      bio: '15 years experience, specializes in algebra and calculus',
      degree: 'M.Sc Mathematics, B.Ed'
    },
    { 
      name: 'Mr. Panna Lal Saini', 
      subject: 'Mathematics', 
      photo: teacher2,
      bio: '17 years experience, specializes in algebra and calculus',
      degree: 'M.com Economics'
    },
    { 
      name: 'Ms. Rina Joshi', 
      subject: 'English Literature', 
      photo: teacher3,
      bio: 'Passionate about creative writing and critical analysis',
      degree: 'MA English, Cambridge CELTA certified'
    },
  ];

  return (
    <div className="teachers-page">
      {/* Hero Section */}
      <div className="teachers-hero">
        <div className="hero-overlay">
          <Fade direction="down" duration={1500} triggerOnce>
            <h1>Our Inspiring Educators</h1>
            <p>Dedicated professionals shaping young minds</p>
          </Fade>
        </div>
      </div>

      {/* Teachers Grid */}
      <section className="teachers-section">
        <div className="container">
          <Zoom triggerOnce>
            <h2>Meet Our Faculty</h2>
            <div className="divider"></div>
          </Zoom>
          
          <div className="teacher-cards">
            {teachers.map((teacher, index) => (
              <Fade key={index} direction="up" delay={index * 100} triggerOnce>
                <div className="teacher-card" data-aos="flip-left">
                  <div className="card-inner">
                    <div className="card-front">
                      <img src={teacher.photo} alt={teacher.name} className="teacher-photo" />
                      <h3>{teacher.name}</h3>
                      <p className="subject">{teacher.subject}</p>
                    </div>
                    <div className="card-back">
                      <h4>About {teacher.name.split(' ')[1]}</h4>
                      <p>{teacher.bio}</p>
                      <p className="degree">{teacher.degree}</p>
                    </div>
                  </div>
                </div>
              </Fade>
            ))}
          </div>
        </div>
      </section>

      {/* Philosophy Section */}
      <section className="philosophy-section" data-aos="fade-up">
        <div className="container">
          <h2>Our Teaching Philosophy</h2>
          <div className="philosophy-content">
            <Fade cascade damping={0.1} triggerOnce>
              <p>We believe every student has unique potential waiting to be unlocked. Our teachers combine academic excellence with compassionate mentorship to create an environment where students thrive.</p>
              <p>With an average of 12 years teaching experience, our faculty brings both expertise and enthusiasm to the classroom every day.</p>
            </Fade>
          </div>
        </div>
      </section>
    </div>
  );
}

export default TeachersPage;