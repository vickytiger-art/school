// Home.js
import React, { useEffect } from 'react';
import './Home.css';
import AOS from 'aos';
import 'aos/dist/aos.css';
import { Swiper, SwiperSlide } from 'swiper/react';
import 'swiper/css';
import 'swiper/css/autoplay';
import { Autoplay } from 'swiper/modules';
import { Link } from 'react-router-dom';

function Home() {
  useEffect(() => {
    AOS.init({ duration: 1200 });
  }, []);

  return (
    <div className="home">
      {/* Navbar */}
      <nav className="navbar">
        <div className="logo">🌟 SchoolZone</div>
        <ul className="nav-links">
          <li><a href="#about">About Us</a></li>
          <li><a href="#library">Library</a></li>
          <li><a href="#teachers">Teachers</a></li>
          <li><a href="#students">Top Students</a></li>
          <li><a href="#events">Events</a></li>
          <li><a href="#contact">Contact Us</a></li>
        </ul>
      </nav>

      {/* Hero Slider */}
      <section className="hero-slider">
        <Swiper
          modules={[Autoplay]}
          autoplay={{ delay: 5000 }}
          loop
          className="swiper-container"
        >
          {[
            { text: 'Education is the passport to the future', img: '/img/slide1.webp' },
            { text: 'Empowering young minds for a brighter tomorrow', img: '/img/slide2.webp' },
            { text: 'A place to learn, grow, and shine', img: '/img/slide3.webp' },
            { text: 'A place to learn, grow, and shine', img: '/img/slide4.webp' },
          ].map((item, index) => (
            <SwiperSlide key={index}>
              <div className="slide" style={{ backgroundImage: `url(${item.img})` }}>
                <h2>{item.text}</h2>
              </div>
            </SwiperSlide>
          ))}
        </Swiper>
      </section>

      {/* School Info Sections */}
      <section id="library" className="info-section" data-aos="fade-up">
        <div className="info-content">
          <img src="/img/library.jpg" alt="Library" />
          <div>
            <h3>Library</h3>
            <p>Our library has a rich collection of over 10,000 books and digital resources.</p>
          </div>
        </div>
      </section>

      <section className="info-section reverse" data-aos="fade-up">
        <div className="info-content">
          <div>
          <Link to="../playground"><h3>Playground</h3></Link>
            <p>Our playground is equipped for cricket, football, kabaddi, and more!</p>
          </div>
          <img src="/img/playground.jpg" alt="playground" />
        </div>
      </section>

      <section className="info-section" data-aos="fade-up">
        <div className="info-content">
          <img src="/img/prayer.jpg" alt="Prayer Ground" />
          <div>
          <Link to="../prayer"><h3>Prayer Ground</h3></Link>
          {/* <Link to="../prayerground">Prayer Ground</Link> */}
            <p>A peaceful area where morning prayers and yoga are practiced daily.</p>
          </div>
        </div>
      </section>

      <section className="info-section reverse" data-aos="fade-up">
        <div className="info-content">
          <div>
          <Link to="../canteen"><h3>Canteen</h3></Link>
            {/* <h3>Canteen</h3> */}
            <p>Nutritious, hygienic, and affordable food options available daily.</p>
          </div>
          <img src="/img/canteen.jpg" alt="Canteen" />
        </div>
      </section>

      <section className="info-section" data-aos="fade-up">
        <div className="info-content">
          <img src="/img/school.jpg" alt="Prayer Ground" />
          <div>
          <Link to="../transport"><h3>Transpot</h3></Link>
            {/* <h3>Transpot</h3> */}
            <p>A peaceful area where morning prayers and yoga are practiced daily.</p>
          </div>
        </div>
      </section>

      {/* Teachers Section */}
      <section id="teachers" className="section glass" data-aos="zoom-in">
        <h2>Meet Our Teachers</h2>
        <div className="card-grid">
          {[...Array(4)].map((_, i) => (
            <div key={i} className="card">
              <img src="/img/teacher.jpg" alt="Teacher" />
              <Link to="../teachers"><h3>Teacher Name</h3></Link>
              {/* <h4>Teacher Name</h4> */}
              <p>Subject: Science</p>
            </div>
          ))}
        </div>
      </section>

      {/* Top Students */}
      <section id="students" className="section light-bg" data-aos="zoom-in-up">
        <h2>Top Students</h2>
        <div className="card-grid">
          {[...Array(4)].map((_, i) => (
            <div key={i} className="card">
              <img src="/img/teacher.jpg" alt="Student" />
              <Link to="../students"><h3>Top Student</h3></Link>
              <p>Topper: Student Name</p>
            </div>
          ))}
        </div>
      </section>

      {/* Events Section */}
      <section id="events" className="section gradient-bg" data-aos="fade-right">
        {/* <h2></h2> */}
        <Link to="../events"><h2>Farewell & Annual Functions</h2></Link>
        <div className="gallery">
          {[...Array(4)].map((_, i) => (
            <img key={i} src="/img/farewell.jpg" alt="Event" />
          ))}
        </div>
      </section>

      {/* About School */}
      <section id="about" className="section glass" data-aos="fade-up">
        <h2>About Our School</h2>
        <div className="about-grid">
          <img src="/img/principal.jpg" alt="Principal" />
          <div>
            <h4>Principal's Message</h4>
            <p>Welcome to our school! We nurture every student to reach their full potential.</p>
            <h4>Vice Principal's Thought</h4>
            <p>Let’s guide every child with empathy and inspiration.</p>
            <h4>School Note</h4>
            <p>We stand for excellence, discipline, and creativity!</p>
          </div>
        </div>
      </section>

      {/* Contact & Footer */}
      <section id="contact" className="section contact-section" data-aos="fade-up">
        <h2>Contact Us</h2>
        <form>
          <input type="text" placeholder="Your Name" required />
          <input type="email" placeholder="Email" required />
          <textarea placeholder="Your Message" required></textarea>
          <button type="submit">Send</button>
        </form>
      </section>

      <footer className="footer">
        <div className="footer-bg">
          <h3>🌸 Thank you for visiting our School Website!</h3>
        </div>
      </footer>
    </div>
  );
}

export default Home;
