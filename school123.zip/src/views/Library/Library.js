// import React, { useState, useEffect } from "react";
// import "./storyfetcher.css";

// const StoryFetcher = () => {
//   const [story, setStory] = useState(null);

//   // Function to open Hindwi and get the first story
//   const fetchStoryFromHindwi = () => {
//     // Open Hindwi.org in a new tab
//     const newTab = window.open("https://www.hindwi.org/kahaniyan", "_blank");

//     // Wait for a few seconds to let the page load
//     setTimeout(() => {
//       try {
//         // Select the first story link on Hindwi
//         const firstStory = newTab.document.querySelector(".work-list a");

//         if (firstStory) {
//           const storyLink = "https://www.hindwi.org" + firstStory.getAttribute("href");
//           const storyTitle = firstStory.textContent.trim();

//           // Update state with the fetched story
//           setStory({ title: storyTitle, link: storyLink });
//         }
//       } catch (error) {
//         console.error("Error fetching story:", error);
//       }
//     }, 3000); // Wait 3 seconds to load the page
//   };

//   // Fetch a new story every minute
//   useEffect(() => {
//     fetchStoryFromHindwi();
//     const interval = setInterval(fetchStoryFromHindwi, 60000); // Refresh every minute

//     return () => clearInterval(interval);
//   }, []);

//   return (
//     <div className="story-container">
//       <h2>📖 Incredible Free Stories</h2>

//       {story ? (
//         <div className="story-card">
//           <h3 className="story-title">{story.title}</h3>
//           <a href={story.link} target="_blank" rel="noopener noreferrer" className="read-more">
//             ➡️ Read Full Story
//           </a>
//         </div>
//       ) : (
//         <p>Loading story...</p>
//       )}
//     </div>
//   );
// };

// export default StoryFetcher;
// // 