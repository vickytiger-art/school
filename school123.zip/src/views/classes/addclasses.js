import React, { useState, useEffect } from 'react';
import {
  CForm,
  CButton,
  CCol,
  CRow,
  CFormCheck,
} from '@coreui/react';
import { useNavigate } from 'react-router-dom';
import './class.css';

const ClassSelection = () => {
  const [selectedClasses, setSelectedClasses] = useState([]);  // For checked classes (IDs)
  const [classList, setClassList] = useState([]); // For class data from API
  const navigate = useNavigate();

  const token = 'Bearer 12345678'; // your token (full token here)

  // Fetch classes on page load
  useEffect(() => {
    fetch('http://localhost:5000/api/getClasses', {
      method: 'GET',
      headers: {
        Authorization: token,
      },
    })
      .then((res) => res.json())
      .then((data) => {
        setClassList(data);
        // Preselect classes where status = 1
        const preselected = data.filter(cls => cls.status === "1").map(cls => cls.id);
        setSelectedClasses(preselected);
      })
      .catch((error) => {
        console.error('Error fetching classes:', error);
        console.log('Failed to load classes');
      });
  }, []);

  // Handle checkbox selection
  const handleCheckboxChange = (classId) => {
    setSelectedClasses((prev) =>
      prev.includes(classId)
        ? prev.filter((id) => id !== classId)
        : [...prev, classId]
    );
  };

  // Handle "Next" button click
  const handleNext = () => {
    if (selectedClasses.length === 0) {
      alert('Please select at least one class!');
      return;
    }

    fetch('http://localhost:5000/api/addOrUpdateClasses', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: token,
      },
      body: JSON.stringify({ classIds: selectedClasses }),
    })
      .then((response) => {
        if (response.ok) {
          alert('Classes updated successfully!');
          window.location.reload();
          // navigate('/classes/addsections'); // Uncomment if you want to move to next page
        } else {
          alert('Failed to update classes.');
        }
      })
      .catch((error) => {
        console.error('Error:', error);
        alert('An error occurred. Please try again.');
      });
  };

  return (
    <>
      <CCol md={8} className="mx-auto p-4 border rounded shadow-sm">
        <h3 className="text-center mb-4">Select Classes</h3>
        <CForm>
          <CRow className="c-row">
            {classList.map((cls) => (
              <CCol key={cls.id} xs={6} sm={4} lg={3} className="c-col">
                <CFormCheck
                  id={`class-${cls.id}`}
                  label={cls.class_name}
                  value={cls.id}
                  onChange={() => handleCheckboxChange(cls.id)}
                  checked={selectedClasses.includes(cls.id)}
                />
              </CCol>
            ))}
          </CRow>
          <div className="text-center mt-4">
            <CButton color="primary" onClick={handleNext}>
              Next
            </CButton>
          </div>
        </CForm>
      </CCol>
    </>
  );
};

export default ClassSelection;
