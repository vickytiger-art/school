import React, { useState } from 'react';
import { DataGrid } from '@mui/x-data-grid';
import { Button, Dialog, TextField, IconButton, MenuItem, Select } from '@mui/material';
import { Edit } from '@mui/icons-material';
import './testlist.css';

const TestList = () => {
  const [open, setOpen] = useState(false);
  const [editData, setEditData] = useState(null);
  const [selectedTest, setSelectedTest] = useState(1);
  const [file, setFile] = useState(null);

  // Sample Data
  const [tests, setTests] = useState([
    { id: 1, rollNo: 101, testNo: 1, Math: 85, Science: 78, English: 90 },
    { id: 2, rollNo: 102, testNo: 1, Math: 72, Science: 88, English: 81 },
    { id: 3, rollNo: 101, testNo: 2, Math: 91, Science: 79, English: 85 },
    { id: 4, rollNo: 102, testNo: 2, Math: 80, Science: 84, English: 76 },
  ]);

  // Handle Test Selection
  const handleTestChange = (event) => {
    setSelectedTest(event.target.value);
  };

  // Handle File Upload
  const handleFileUpload = (e) => {
    setFile(e.target.files[0]);
    alert('File uploaded successfully');
  };

  // Handle Edit
  const handleEdit = () => {
    setTests(tests.map(test => (test.id === editData.id ? editData : test)));
    setOpen(false);
  };

  // Filter Data Based on Selected Test
  const filteredTests = tests.filter(test => test.testNo === selectedTest);

  const columns = [
    { field: 'rollNo', headerName: 'Roll No', width: 100 },
    { field: 'Math', headerName: 'Math', width: 120, editable: true },
    { field: 'Science', headerName: 'Science', width: 120, editable: true },
    { field: 'English', headerName: 'English', width: 120, editable: true },
    {
      field: 'actions',
      headerName: 'Edit',
      width: 80,
      renderCell: (params) => (
        <IconButton onClick={() => { setEditData(params.row); setOpen(true); }}>
          <Edit />
        </IconButton>
      ),
    },
  ];

  return (
    <div className="testlist-container">
      <h2>Test Records</h2>

      {/* Controls: Select Test & Upload */}
      <div className="controls">
        <Select value={selectedTest} onChange={handleTestChange}>
          <MenuItem value={1}>First Test</MenuItem>
          <MenuItem value={2}>Second Test</MenuItem>
          <MenuItem value={3}>Third Test</MenuItem>
          <MenuItem value={4}>Fourth Test</MenuItem>
          <MenuItem value={5}>Fifth Test</MenuItem>
        </Select>
        <input type="file" accept=".csv,.xlsx" onChange={handleFileUpload} />
        <Button variant="contained" color="primary">Upload CSV/Excel</Button>
      </div>

      {/* Data Table */}
      <div className="table-container">
        <DataGrid rows={filteredTests} columns={columns} pageSize={5} autoHeight />
      </div>

      {/* Edit Dialog */}
      <Dialog open={open} onClose={() => setOpen(false)}>
        <div className="edit-popup">
          <h3>Edit Marks</h3>
          <TextField
            label="Math"
            value={editData?.Math}
            onChange={(e) => setEditData({ ...editData, Math: e.target.value })}
          />
          <TextField
            label="Science"
            value={editData?.Science}
            onChange={(e) => setEditData({ ...editData, Science: e.target.value })}
          />
          <TextField
            label="English"
            value={editData?.English}
            onChange={(e) => setEditData({ ...editData, English: e.target.value })}
          />
          <Button onClick={handleEdit}>Save</Button>
        </div>
      </Dialog>
    </div>
  );
};

export default TestList;
