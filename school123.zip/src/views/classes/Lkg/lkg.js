import React, { useState, useEffect } from 'react';
import './lkg.css';
import { DataGrid } from '@mui/x-data-grid';
import { TextField, Button, Checkbox, IconButton, Paper, MenuItem } from '@mui/material';
import { Edit, Delete, Assessment, Description } from '@mui/icons-material';
import { useNavigate } from 'react-router-dom';
// import axios from 'axios';

const StudentAttendance = () => {
  const [search, setSearch] = useState('');
  const [selectedSection, setSelectedSection] = useState('');
  const [students, setStudents] = useState([]);
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  // Available sections
  const sections = ['A', 'B', 'C'];
  const classnameforrepoert ='lkg';

  // Fetch LKG students on component mount
  useEffect(() => {
    const fetchStudents = async () => {
      setLoading(true);
      try {
        const response = await fetch('http://localhost:5000/api/getStudents?class=lkg');
        const data = await response.json();
        const formattedStudents = data.data.map(student => ({
          ...student,
          present: student.present === 1
        }));
        setStudents(formattedStudents);
      } catch (error) {
        console.error('Error fetching students:', error);
      } finally {
        setLoading(false);
      }
    };
  
    fetchStudents();
  }, []);
  

  // Toggle Attendance - Now updates both UI and API
  const handleAttendanceChange = async (id) => {
    const updatedStudents = students.map(student =>
      student.id === id ? { ...student, present: !student.present } : student
    );
    setStudents(updatedStudents);

    // Update in API
    try {
      const studentToUpdate = updatedStudents.find(s => s.id === id);
      await axios.patch(`http://localhost:5000/api/students/${id}`, {
        present: studentToUpdate.present ? 1 : 0
      });
    } catch (error) {
      console.error('Error updating attendance:', error);
    }
  };

  // Rest of your existing handlers remain exactly the same
  const handleSearch = (e) => {
    setSearch(e.target.value);
  };

  const handleSectionChange = (e) => {
    setSelectedSection(e.target.value);
  };

  const handleAddStudent = () => {
    navigate('/classes/Lkg/Addlkgstudent');
  };

  const handleEditStudent = (id) => {
    navigate(`/classes/Lkg/Editlkgstudent/${id}`);
  };

  const handletest = () => {
    navigate('/classes/Lkg/Testlistpage');
  };

  const handlereport = (className, rollno) => {
    navigate('/classes/Lkg/StudentReports', {
      state: { className, rollno }
    });
  };

  // Filter Students by Name and Section
  const filteredStudents = students.filter(
    (student) =>
      student.name.toLowerCase().includes(search.toLowerCase()) &&
      (selectedSection ? student.section === selectedSection : true)
  );

  // Table Columns remain exactly the same
  const columns = [
    {
      field: 'present',
      headerName: 'Attendance',
      width: 120,
      renderCell: (params) => (
        <Checkbox
          checked={params.row.present}
          onChange={() => handleAttendanceChange(params.row.id)}
        />
      ),
    },
    { field: 'section', headerName: 'Section', width: 100 },
    { field: 'rollNo', headerName: 'Roll No', width: 100 },
    { field: 'name', headerName: 'Student Name', width: 180 },
    { field: 'fatherName', headerName: `Father's Name`, width: 180 },
    { field: 'contact', headerName: 'Contact Number', width: 150 },
    {
      field: 'actions',
      headerName: 'Actions',
      width: 120,
      renderCell: (params) => (
        <>
          <IconButton onClick={() => handleEditStudent(params.row.id)} color="primary">
            <Edit />
          </IconButton>
          <IconButton color="secondary">
            <Delete />
          </IconButton>
        </>
      ),
    },
    {
      field: 'reports',
      headerName: 'Reports',
      width: 150,
      renderCell: (params) => (
        <>
          <IconButton onClick={handletest} color="primary">
            <Assessment />
          </IconButton>
          <IconButton onClick={() => handlereport(classnameforrepoert, params.row.rollNo)} color="secondary">
  <Description />
</IconButton>

        </>
      ),
    },
  ];

  return (
    <div className="attendance-container">
      <h2 className="attendance-title">Student Attendance</h2>

      {/* Controls: Search and Section Selection */}
      <div className="attendance-controls">
        <TextField
          label="Search Student"
          variant="outlined"
          size="small"
          value={search}
          onChange={handleSearch}
        />
        <TextField
          select
          label="Select Section"
          value={selectedSection}
          onChange={handleSectionChange}
          variant="outlined"
          size="small"
        >
          <MenuItem value="">All Sections</MenuItem>
          {sections.map((sec) => (
            <MenuItem key={sec} value={sec}>{sec}</MenuItem>
          ))}
        </TextField>
        <Button
          onClick={() => navigate('/classes/Lkg/lkgFeeList')}
          variant="contained"
          color="secondary"
          className="fee-management-btn"
        >
          Manage Fees
        </Button>
        <Button onClick={handleAddStudent} variant="contained" color="primary" className="add-student-btn">
          Add Student
        </Button>
      </div>

      {/* Attendance Table */}
      <Paper className="attendance-table-container">
        <DataGrid
          rows={filteredStudents}
          columns={columns}
          pageSize={5}
          autoHeight
          loading={loading}
        />
      </Paper>
    </div>
  );
};

export default StudentAttendance;