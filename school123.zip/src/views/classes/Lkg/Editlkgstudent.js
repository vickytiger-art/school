import React, { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import './Addlkg.css';

const EditLkgStudent = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const [photo, setPhoto] = useState(null);
  const [aadhaarCard, setAadhaarCard] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [showPopup, setShowPopup] = useState(false);
  const [existingImages, setExistingImages] = useState({
    profilePhoto: '',
    aadhaarCard: ''
  });
  console.log('profilePhoto', existingImages)

  const [formData, setFormData] = useState({
    rollno: '',
    name: '',
    fathername: '',
    className:'lkg',
    dob: '',
    admissiondate: '',
    mobno: '',
    email: '',
    desc: '',
    assignclass: '',
    persentaddress: '',
    address: '',
    totalfees: '',
    duefees: '',
    paidfees: '',
    section: '',
    thirdchild: ''
  });

  console.log('formdata',formData)

  // Fetch student data when component mounts
  useEffect(() => {
    const fetchStudent = async () => {
      try {
        const response = await fetch(`http://localhost:5000/api/getStudentById/${id}`);
        const data = await response.json();
        
        if (data.success) {
          const d = data.data;
        
          setFormData({
            rollno: d.rollno || '',
            name: d.name?.trim() || '',
            fathername: d.fathername?.trim() || '',
            dob: d.dob?.trim() || '',
            admissiondate: d.admissiondate?.trim() || '',
            mobno: d.mobno?.trim() || '',
            email: d.email?.trim() || '',
            desc: d.desc?.trim() || '',
            assignclass: d.assignclass?.trim() || '',
            persentaddress: d.persentaddress?.trim() || '',
            address: d.address?.trim() || '',
            totalfees: d.totalfees?.trim() || '',
            duefees: d.duefees?.trim() || '',
            paidfees: d.paidfees?.trim() || '',
            section: d.section?.trim() || '',
            thirdchild: d.thirdchild?.trim() || '',
            className: d.class?.trim() || ''
          });

          setExistingImages({
            profilePhoto: d.profilephoto ? `http://localhost:3000/api${d.profilephoto}` : '',
            aadhaarCard: d.adharcard ? `http://localhost:3000/api${d.adharcard}` : ''
          });

        }
      }
         catch (error) {
        console.error('Error fetching student:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchStudent();
  }, [id]);

  const handlePhotoChange = (e) => {
    const file = e.target.files[0];
    if (file) setPhoto(file);
  };

  const handleCardChange = (e, setCardFunction) => {
    const file = e.target.files[0];
    if (file) setCardFunction(file);
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');

    const formDataToSubmit = new FormData();
    if (photo) formDataToSubmit.append('profilephoto', photo);
    if (aadhaarCard) formDataToSubmit.append('adharcard', aadhaarCard);
    
    // Append all form data
    for (const key in formData) {
      formDataToSubmit.append(key, formData[key]);
    }

    try {
      const response = await fetch(`http://localhost:5000/api/editStudent/${id}`, {
        method: 'POST',
        body: formDataToSubmit,
      });

      const data = await response.json();
      
      if (data.success) {
        setShowPopup(true);
        setTimeout(() => navigate('/classes/Lkg/lkg'), 2000);
      } else {
        setError(data.message || 'Failed to update student');
      }
    } catch (error) {
      console.error('Error:', error);
      setError('An error occurred while submitting the form');
    }
  };

  if (loading) return <div className="container">Loading student data...</div>;

  return (
    <div>
      <div className="container">
        <h2 className="title">Edit LKG Student</h2>
        <form onSubmit={handleSubmit} className="form">
          {/* Photo Section */}
          <div className="photoSection">
            <label htmlFor="photoUpload" className="photoUploadLabel">
              {photo ? (
                <img src={URL.createObjectURL(photo)} alt="Student" className="photo" />
              ) : existingImages.profilePhoto ? (
                <img src={existingImages.profilePhoto} alt="Student" className="photo" />
              ) : (
                <div className="photoPlaceholder">Update Profile Photo</div>
              )}
            </label>
            <input
              id="photoUpload"
              type="file"
              accept="image/*"
              onChange={handlePhotoChange}
              className="fileInput"
              style={{ display: 'none' }}
            />
          </div>

          {/* Student Information Fields */}
          <div className="fieldGroup">
            <label className="label">Roll No:</label>
            <input
              type="text"
              className="input"
              name="rollno"
              value={formData.rollno}
              onChange={handleInputChange}
              required
            />
          </div>

          <div className="fieldGroup">
            <label className="label">Name:</label>
            <input
              type="text"
              className="input"
              name="name"
              value={formData.name}
              onChange={handleInputChange}
              required
            />
          </div>

          <div className="fieldGroup">
            <label className="label">Father's Name:</label>
            <input
              type="text"
              className="input"
              name="fathername"
              value={formData.fathername}
              onChange={handleInputChange}
              required
            />
          </div>

          <div className="fieldGroup">
            <label className="label">Date of Birth:</label>
            <input
              type="date"
              className="input"
              name="dob"
              value={formData.dob}
              onChange={handleInputChange}
              required
            />
          </div>

          <div className="fieldGroup">
            <label className="label">Admission Date:</label>
            <input
              type="date"
              className="input"
              name="admissiondate"
              value={formData.admissiondate}
              onChange={handleInputChange}
              required
            />
          </div>

          <div className="fieldGroup">
            <label className="label">Mobile Number:</label>
            <input
              type="tel"
              className="input"
              name="mobno"
              value={formData.mobno}
              onChange={handleInputChange}
              required
            />
          </div>

          <div className="fieldGroup">
            <label className="label">Email:</label>
            <input
              type="email"
              className="input"
              name="email"
              value={formData.email}
              onChange={handleInputChange}
            />
          </div>

          <div className="fieldGroup">
            <label className="label">Section:</label>
            <select
              className="input"
              name="section"
              value={formData.section}
              onChange={handleInputChange}
              required
            >
              <option value="">Select Section</option>
              <option value="A">A</option>
              <option value="B">B</option>
              <option value="C">C</option>
            </select>
          </div>

          <div className="fieldGroup">
            <label className="label">Third Child:</label>
            <select
              className="input"
              name="thirdchild"
              value={formData.thirdchild}
              onChange={handleInputChange}
            >
              <option value="No">No</option>
              <option value="Yes">Yes</option>
            </select>
          </div>

          <div className="fieldGroup grid-column-span">
            <label className="label">Description:</label>
            <input
              type="text"
              className="input"
              name="desc"
              value={formData.desc}
              onChange={handleInputChange}
              placeholder="Enter description"
            />
          </div>

          {/* <div className="fieldGroup">
            <label className="label">Assigned Class:</label>
            <input
              type="text"
              className="input"
              name="assignclass"
              value={formData.assignclass}
              onChange={handleInputChange}
              required
            />
          </div> */}

          <div className="fieldGroup grid-column-span">
            <label className="label">Present Address:</label>
            <input
              type="text"
              className="input"
              name="persentaddress"
              value={formData.persentaddress}
              onChange={handleInputChange}
              required
            />
          </div>

          <div className="fieldGroup grid-column-span">
            <label className="label">Permanent Address:</label>
            <input
              type="text"
              className="input"
              name="address"
              value={formData.address}
              onChange={handleInputChange}
              required
            />
          </div>

          <div className="fieldGroup">
            <label className="label">Total Fees:</label>
            <input
              type="number"
              className="input"
              name="totalfees"
              value={formData.totalfees}
              onChange={handleInputChange}
              required
            />
          </div>

          <div className="fieldGroup">
            <label className="label">Due Fees:</label>
            <input
              type="number"
              className="input"
              name="duefees"
              value={formData.duefees}
              onChange={handleInputChange}
              required
            />
          </div>

          <div className="fieldGroup">
            <label className="label">Paid Fees:</label>
            <input
              type="number"
              className="input"
              name="paidfees"
              value={formData.paidfees}
              onChange={handleInputChange}
              required
            />
          </div>

          {/* Aadhaar Card Upload */}
          <div className='photodiv'>
            <div className="photoSection">
              <label htmlFor="aadhaarCard" className="photoUploadLabel">
                {aadhaarCard ? (
                  <img src={URL.createObjectURL(aadhaarCard)} alt="Aadhaar" className="photo" />
                ) : existingImages.aadhaarCard ? (
                  <img src={existingImages.aadhaarCard} alt="Aadhaar" className="photo" />
                ) : (
                  <div className="photoPlaceholder">Update Aadhaar Card</div>
                )}
              </label>
              <input
                id="aadhaarCard"
                type="file"
                accept="image/*"
                onChange={(e) => handleCardChange(e, setAadhaarCard)}
                className="fileInput"
                style={{ display: 'none' }}
              />
            </div>
          </div>

          {error && <p className="error">{error}</p>}
          <button type="submit" className="submitBtn">Update Student</button>
        </form>

        {showPopup && (
          <div className="popup-overlay">
            <div className="popup">
              <h3>Student updated successfully!</h3>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default EditLkgStudent;