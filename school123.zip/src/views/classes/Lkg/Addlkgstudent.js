import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import './Addlkg.css';

const AddTeachers = () => {
    const [photo, setPhoto] = useState(null);
    const [aadhaarCard, setAadhaarCard] = useState(null);
    const [isAdmin, setIsAdmin] = useState(false);
    const [loading, setLoading] = useState(true);
    const navigate = useNavigate();

    const [formData, setFormData] = useState({
        rollno: '',
        name: '',
        fatherName: '',
        dob: '',
        mobile: '',
        email: '',
        description: '',
        presentAddress: '',
        permanentAddress: '',
        class: 'lkg',
        section: '',
        thirdchild: '',
        admissiondate: '',
        totalfees: '',
        duefees: '',
        paidfees: ''
    });

    const [error, setError] = useState('');
    const [showPopup, setShowPopup] = useState(false);

    const handlePhotoChange = (e) => {
        const file = e.target.files[0];
        if (file) {
            setPhoto(file);
        }
    };

    const handleCardChange = (e, setCardFunction) => {
        const file = e.target.files[0];
        if (file) {
            setCardFunction(file);
        }
    };

    const handleInputChange = (e) => {
        const { name, value } = e.target;
        setFormData((prevData) => ({
            ...prevData,
            [name]: value,
        }));
    };

    const handleSubmit = async (e) => {
        e.preventDefault();

        if (!aadhaarCard) {
            setError('Aadhaar card is required.');
            return;
        }

        setError('');

        const formDataToSubmit = new FormData();
        formDataToSubmit.append('profilephoto', photo);
        formDataToSubmit.append('adharcard', aadhaarCard);
        
        // Append all form data
        for (const key in formData) {
            formDataToSubmit.append(key, formData[key]);
        }

        try {
            const response = await fetch('http://localhost:5000/api/addstudent', {
                method: 'POST',
                body: formDataToSubmit,
            });

            if (response.ok) {
                setShowPopup(true);
                setTimeout(() => {
                    setShowPopup(false);
                    navigate('/');
                }, 2000);
            } else {
                const errorData = await response.json();
                setError(errorData.message || 'Failed to add student data. Please try again.');
            }
        } catch (error) {
            console.error('Error:', error);
            setError('An error occurred while submitting the form. Please try again.');
        }
    };

    return (
        <div>
            <div className="container">
                <h2 className="title">Add New Student</h2>
                <form onSubmit={handleSubmit} className="form">
                    {/* Photo Section */}
                    <div className="photoSection">
                        <label htmlFor="photoUpload" className="photoUploadLabel">
                            {photo ? (
                                <img src={URL.createObjectURL(photo)} alt="Student" className="photo" />
                            ) : (
                                <div className="photoPlaceholder">Choose Profile Photo</div>
                            )}
                        </label>
                        <input
                            id="photoUpload"
                            type="file"
                            accept="image/*"
                            onChange={handlePhotoChange}
                            className="fileInput"
                            style={{ display: 'none' }}
                            required
                        />
                    </div>

                    {/* Roll No */}
                    <div className="fieldGroup">
                        <label className="label">Roll No:</label>
                        <input
                            type="text"
                            className="input"
                            name="rollno"
                            value={formData.rollno}
                            onChange={handleInputChange}
                            placeholder="Enter Roll Number"
                            required
                        />
                    </div>

                    {/* Name */}
                    <div className="fieldGroup">
                        <label className="label">Name:</label>
                        <input
                            type="text"
                            className="input"
                            name="name"
                            value={formData.name}
                            onChange={handleInputChange}
                            placeholder="Enter Name"
                            required
                        />
                    </div>

                    {/* Father's Name */}
                    <div className="fieldGroup">
                        <label className="label">Father's Name:</label>
                        <input
                            type="text"
                            className="input"
                            name="fatherName"
                            value={formData.fatherName}
                            onChange={handleInputChange}
                            placeholder="Enter Father's Name"
                            required
                        />
                    </div>

                    {/* Date of Birth */}
                    <div className="fieldGroup">
                        <label className="label">Date of Birth:</label>
                        <input
                            type="date"
                            className="input"
                            name="dob"
                            value={formData.dob}
                            onChange={handleInputChange}
                            required
                        />
                    </div>

                    {/* Class */}
                    <div className="fieldGroup">
                        <label className="label">Class:</label>
                        <input
                            type="text"
                            className="input"
                            name="class"
                            value={formData.class}
                            onChange={handleInputChange}
                            placeholder="Enter Class"
                            required
                        />
                    </div>

                    {/* Section */}
                    <div className="fieldGroup">
                        <label className="label">Section:</label>
                        <input
                            type="text"
                            className="input"
                            name="section"
                            value={formData.section}
                            onChange={handleInputChange}
                            placeholder="Enter Section"
                            required
                        />
                    </div>

                    {/* Third Child */}
                    <div className="fieldGroup">
                        <label className="label">Third Child:</label>
                        <input
                            type="text"
                            className="input"
                            name="thirdchild"
                            value={formData.thirdchild}
                            onChange={handleInputChange}
                            placeholder="Enter Third Child Status"
                        />
                    </div>

                    {/* Admission Date */}
                    <div className="fieldGroup">
                        <label className="label">Admission Date:</label>
                        <input
                            type="date"
                            className="input"
                            name="admissiondate"
                            value={formData.admissiondate}
                            onChange={handleInputChange}
                            required
                        />
                    </div>

                    {/* Mobile Number */}
                    <div className="fieldGroup">
                        <label className="label">Mobile Number:</label>
                        <input
                            type="tel"
                            className="input"
                            name="mobile"
                            value={formData.mobile}
                            onChange={handleInputChange}
                            placeholder="Enter Mobile Number"
                            required
                        />
                    </div>

                    {/* Email */}
                    <div className="fieldGroup">
                        <label className="label">Email:</label>
                        <input
                            type="email"
                            className="input"
                            name="email"
                            value={formData.email}
                            onChange={handleInputChange}
                            placeholder="Enter Email"
                            required
                        />
                    </div>

                    {/* Description */}
                    <div className="fieldGroup grid-column-span">
                        <label className="label">Description:</label>
                        <input
                            type="text"
                            className="input"
                            name="description"
                            value={formData.description}
                            onChange={handleInputChange}
                            placeholder="Enter Description"
                            required
                        />
                    </div>

                    {/* Present Address */}
                    <div className="fieldGroup grid-column-span">
                        <label className="label">Present Address:</label>
                        <input
                            type="text"
                            className="input"
                            name="presentAddress"
                            value={formData.presentAddress}
                            onChange={handleInputChange}
                            placeholder="Enter Present Address"
                            required
                        />
                    </div>

                    {/* Permanent Address */}
                    <div className="fieldGroup grid-column-span">
                        <label className="label">Permanent Address:</label>
                        <input
                            type="text"
                            className="input"
                            name="permanentAddress"
                            value={formData.permanentAddress}
                            onChange={handleInputChange}
                            placeholder="Enter Permanent Address"
                            required
                        />
                    </div>

                    {/* Fees Information */}
                    <div className="fieldGroup">
                        <label className="label">Total Fees:</label>
                        <input
                            type="number"
                            className="input"
                            name="totalfees"
                            value={formData.totalfees}
                            onChange={handleInputChange}
                            placeholder="Enter Total Fees"
                            required
                        />
                    </div>

                    <div className="fieldGroup">
                        <label className="label">Due Fees:</label>
                        <input
                            type="number"
                            className="input"
                            name="duefees"
                            value={formData.duefees}
                            onChange={handleInputChange}
                            placeholder="Enter Due Fees"
                            required
                        />
                    </div>

                    <div className="fieldGroup">
                        <label className="label">Paid Fees:</label>
                        <input
                            type="number"
                            className="input"
                            name="paidfees"
                            value={formData.paidfees}
                            onChange={handleInputChange}
                            placeholder="Enter Paid Fees"
                            required
                        />
                    </div>

                    {/* Aadhaar Card Upload */}
                    <div className='photodiv'>
                        <div className="photoSection">
                            <label htmlFor="aadhaarCard" className="photoUploadLabel">
                                {aadhaarCard ? (
                                    <img src={URL.createObjectURL(aadhaarCard)} alt="Aadhaar" className="photo" />
                                ) : (
                                    <div className="photoPlaceholder">Upload Aadhaar Card</div>
                                )}
                            </label>
                            <input
                                id="aadhaarCard"
                                type="file"
                                accept="image/*"
                                onChange={(e) => handleCardChange(e, setAadhaarCard)}
                                className="fileInput"
                                style={{ display: 'none' }}
                                required
                            />
                        </div>
                    </div>

                    {error && <p className="error">{error}</p>}

                    <button type="submit" className="submitBtn">
                        Submit
                    </button>
                </form>

                {showPopup && (
                    <div className="popup-overlay">
                        <div className="popup">
                            <h3>Student added successfully!</h3>
                        </div>
                    </div>
                )}
            </div>
        </div>
    );
};

export default AddTeachers;