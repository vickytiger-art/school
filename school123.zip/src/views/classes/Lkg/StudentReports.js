import React, { useEffect, useState } from 'react';
import './studentreports.css';
import { useLocation, useNavigate } from 'react-router-dom';

const StudentReports = () => {
  const [reports, setReports] = useState([]);
  const [isPreviewOpen, setPreviewOpen] = useState(false);
  const [currentReport, setCurrentReport] = useState(null);

  const location = useLocation();
  const navigate = useNavigate();
  const { className, rollno } = location.state || {};

  const baseURL = 'http://localhost:5000/api';

  useEffect(() => {
    if (!className || !rollno) {
      alert("Missing student info. Redirecting...");
      navigate('/');
      return;
    }
    fetchReports();
  }, []);

  const fetchReports = async () => {
    try {
      const response = await fetch(`${baseURL}/getReports/${className}/${rollno}`);
      const data = await response.json();
      if (data.success) {
        setReports(data.data);
      }
    } catch (err) {
      console.error('Error fetching reports:', err);
    }
  };

  const handleReportUpload = async (e, replaceId = null) => {
    const file = e.target.files[0];
    if (!file) return;

    const formData = new FormData();
    formData.append('marksheet', file);
    formData.append('rollno', rollno);
    formData.append('class', className);
    formData.append('name', '');

    let url = `${baseURL}/uploadReport`;
    if (replaceId) {
      formData.append('id', replaceId); // You must handle this on the backend
      url = `${baseURL}/updateReport/${replaceId}`;
    }

    try {
      const response = await fetch(url, {
        method: 'POST',
        body: formData,
      });
      const result = await response.json();
      if (result.success) {
        fetchReports();
      } else {
        console.error('Upload error:', result.message);
      }
    } catch (err) {
      console.error('Upload failed:', err);
    }
  };

  const deleteReport = async (id) => {
    if (!window.confirm('Are you sure you want to delete this report?')) return;
    try {
      const response = await fetch(`${baseURL}/deleteReport/${id}`, {
        method: 'DELETE',
      });

      const result = await response.json();
      if (result.success) {
        fetchReports();
      } else {
        console.error('Delete failed:', result.message);
      }
    } catch (err) {
      console.error('Delete error:', err);
    }
  };

  const openPreview = (file) => {
    setCurrentReport(file);
    setPreviewOpen(true);
  };

  const closePreview = () => {
    setPreviewOpen(false);
    setCurrentReport(null);
  };

  const isImage = (filePath) => {
    return /\.(jpg|jpeg|png|gif|webp)$/i.test(filePath);
  };

  const isPDF = (filePath) => {
    return /\.pdf$/i.test(filePath);
  };

  return (
    <div className="reports-container">
      <h2>Upload Student Reports (Class: {className}, Roll No: {rollno})</h2>

      <div className="upload-box">
        <input
          type="file"
          accept="*"
          onChange={(e) => handleReportUpload(e)}
          className="file-input"
        />
      </div>

      <div className="reports-list">
        {reports.length > 0 ? (
          reports.map((report) => (
            <div key={report.id} className="report-card">
              <div className="report-ribbon">Report</div>
              <div className="report-preview" onClick={() => openPreview(report.marksheet)}>
                {isImage(report.marksheet) ? (
                  <img
                    src={`http://localhost:3000/api${report.marksheet}`}
                    alt="Preview"
                  />
                ) : isPDF(report.marksheet) ? (
                  <iframe
                    src={`http://localhost:3000/api${report.marksheet}`}
                    title="PDF Preview"
                    width="100%"
                    height="150px"
                  />
                ) : (
                  <div className="file-name-box">
                    <span>{report.marksheet.split('/').pop()}</span>
                  </div>
                )}
              </div>
              <div className="report-name">{report.name || 'Unnamed Report'}</div>

              <div className="report-actions">
                <label className="replace-label">
                  Replace
                  <input
                    type="file"
                    accept="*"
                    onChange={(e) => handleReportUpload(e, report.id)}
                    className="file-input-hidden"
                  />
                </label>

                <button className="delete-btn" onClick={() => deleteReport(report.id)}>
                  Delete
                </button>
              </div>
            </div>
          ))
        ) : (
          <p>No reports uploaded yet.</p>
        )}
      </div>

      {isPreviewOpen && currentReport && (
        <div className="report-preview-full" onClick={closePreview}>
          {isImage(currentReport) ? (
            <img src={`http://localhost:3000/api${currentReport}`} alt="Preview" />
          ) : isPDF(currentReport) ? (
            <iframe
              src={`http://localhost:3000/api${currentReport}`}
              title="PDF Preview"
              width="90%"
              height="90%"
              style={{ border: 'none', background: '#fff' }}
            />
          ) : (
            <div className="file-name-box">
              <p>Preview not available</p>
              <p>{currentReport.split('/').pop()}</p>
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default StudentReports;
