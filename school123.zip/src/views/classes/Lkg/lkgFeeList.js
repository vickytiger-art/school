import React, { useState, useEffect } from 'react';
import { DataGrid } from '@mui/x-data-grid';
import {
  Paper,
  IconButton,
  TextField,
  CircularProgress,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Button,
  Box,
  useMediaQuery,
  useTheme,
  Typography
} from '@mui/material';
import { Edit, Info } from '@mui/icons-material';
import { useNavigate } from 'react-router-dom';
import './childTheme.css';

const FeeListPage = () => {
  const navigate = useNavigate();
  const [search, setSearch] = useState('');
  const [students, setStudents] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  // Modal state
  const [openEditModal, setOpenEditModal] = useState(false);
  const [selectedStudent, setSelectedStudent] = useState(null);
  const [editTotalFee, setEditTotalFee] = useState('');
  const [editPaidFee, setEditPaidFee] = useState('');
  const [submitLoading, setSubmitLoading] = useState(false);

  const theme = useTheme();
  const fullScreen = useMediaQuery(theme.breakpoints.down('sm'));

  useEffect(() => {
    const fetchFees = async () => {
      try {
        const url = new URL('http://localhost:5000/api/getFees');
        url.searchParams.append('class', 'Lkg');

        const response = await fetch(url, {
          method: 'GET',
          headers: {
            'Content-Type': 'application/json'
          }
        });

        if (!response.ok) {
          throw new Error(`HTTP error! status: ${response.status}`);
        }

        const data = await response.json();

        if (data.success) {
          const formattedData = data.data.map(item => ({
            id: item.id,
            rollNo: item.rollno,
            name: item.name,
            fatherName: item.fathersname,
            totalFee: item.totalfees,
            paidFee: item.submitfees,
            dueFee: item.remainingfees
          }));

          setStudents(formattedData);
        } else {
          setError(data.message || 'Failed to fetch fees data');
        }
      } catch (err) {
        setError(err.message || 'Error fetching fees');
        console.error('Error fetching fees:', err);
      } finally {
        setLoading(false);
      }
    };

    fetchFees();
  }, []);

  // Open modal and populate form fields
  const handleOpenEditModal = (student) => {
    setSelectedStudent(student);
    setEditTotalFee(student.totalFee);
    setEditPaidFee(student.paidFee);
    setOpenEditModal(true);
  };

  // Close modal and reset
  const handleCloseEditModal = () => {
    setOpenEditModal(false);
    setSelectedStudent(null);
    setEditTotalFee('');
    setEditPaidFee('');
  };

  // Submit updated fees
  const handleSubmitEdit = async () => {
    if (editTotalFee === '' || editPaidFee === '') {
      alert('Please fill in all fields.');
      return;
    }
    if (Number(editPaidFee) > Number(editTotalFee)) {
      alert('Paid Fee cannot be more than Total Fee.');
      return;
    }

    setSubmitLoading(true);
    try {
      const dueFee = Number(editTotalFee) - Number(editPaidFee);

      const response = await fetch(`http://localhost:5000/api/editFees/${selectedStudent.id}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          totalfees: Number(editTotalFee),
          submitfees: Number(editPaidFee),
          remainingfees: dueFee
        })
      });

      if (!response.ok) {
        throw new Error('Failed to update fees');
      }

      const data = await response.json();
      if (!data.success) {
        throw new Error(data.message || 'Update failed');
      }

      // Update local state
      setStudents(prev =>
        prev.map(s =>
          s.id === selectedStudent.id
            ? { ...s, totalFee: Number(editTotalFee), paidFee: Number(editPaidFee), dueFee }
            : s
        )
      );

      handleCloseEditModal();
    } catch (err) {
      console.error('Error updating fee:', err);
      alert('Error updating fees. Please try again.');
    } finally {
      setSubmitLoading(false);
    }
  };

  const handleOpenDetails = (student) => {
    navigate('/classes/Lkg/FeeDetailsPage', { state: { student } });
  };

  const columns = [
    { field: 'rollNo', headerName: 'Roll No', width: 100 },
    { field: 'name', headerName: 'Student Name', width: 180 },
    { field: 'fatherName', headerName: "Father's Name", width: 180 },
    { field: 'totalFee', headerName: 'Total Fee', width: 120, type: 'number' },
    { field: 'paidFee', headerName: 'Paid Fee', width: 120, type: 'number' },
    { field: 'dueFee', headerName: 'Due Fee', width: 120, type: 'number' },
    {
      field: 'actions',
      headerName: 'Actions',
      width: 120,
      sortable: false,
      renderCell: (params) => (
        <>
          <IconButton
            color="primary"
            onClick={() => handleOpenEditModal(params.row)}
            aria-label="edit fees"
          >
            <Edit />
          </IconButton>
          <IconButton
            onClick={() => handleOpenDetails(params.row)}
            color="primary"
            aria-label="view details"
          >
            <Info />
          </IconButton>
        </>
      ),
    },
  ];

  const filteredStudents = students.filter((student) =>
    student.name.toLowerCase().includes(search.toLowerCase()) ||
    student.rollNo.toLowerCase().includes(search.toLowerCase())
  );

  const [flowers, setFlowers] = useState([]);

  useEffect(() => {
    const numberOfFlowers = 15;
    const generatedFlowers = Array.from({ length: numberOfFlowers }, (_, index) => {
      const left = Math.random() * 100;
      const delay = Math.random() * 5;
      const duration = 5 + Math.random() * 5;
      return (
        <div
          key={index}
          className="flower"
          style={{
            left: `${left}%`,
            animationDelay: `${delay}s`,
            animationDuration: `${duration}s`
          }}
        />
      );
    });
    setFlowers(generatedFlowers);
  }, []);

  if (loading) {
    return (
      <div className="child-theme-overlay">
        <div className="loading-container">
          <CircularProgress />
          <p>Loading fee data...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="child-theme-overlay">
        <div className="error-container">
          <p>Error: {error}</p>
        </div>
      </div>
    );
  }

  return (
    <div className="child-theme-overlay">
      <div className="flower-rain">{flowers}</div>
      <div className="fee-list-container">
        <h2 className="fee-list-title">Fee List - LKG Class</h2>
        <div style={{ marginBottom: 16 }}>
          <TextField
            label="Search Student"
            variant="outlined"
            size="small"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            style={{ width: '100%' }}
          />
        </div>
        <Paper style={{ padding: 10 }}>
          <DataGrid
            rows={filteredStudents}
            columns={columns}
            pageSize={5}
            autoHeight
            disableSelectionOnClick
          />
        </Paper>
      </div>

      {/* Edit Fee Modal */}
      <Dialog
        fullScreen={fullScreen}
        open={openEditModal}
        onClose={handleCloseEditModal}
        aria-labelledby="edit-fee-dialog-title"
      >
        <DialogTitle id="edit-fee-dialog-title">Edit Fees for {selectedStudent?.name}</DialogTitle>
        <DialogContent>
          <Box
            component="form"
            sx={{
              display: 'flex',
              flexDirection: 'column',
              gap: 2,
              minWidth: fullScreen ? 'auto' : 400,
              pt: 1
            }}
            noValidate
            autoComplete="off"
          >
            <TextField
              label="Total Fee"
              type="number"
              variant="outlined"
              value={editTotalFee}
              onChange={(e) => setEditTotalFee(e.target.value)}
              fullWidth
              inputProps={{ min: 0 }}
            />
            <TextField
              label="Paid Fee"
              type="number"
              variant="outlined"
              value={editPaidFee}
              onChange={(e) => setEditPaidFee(e.target.value)}
              fullWidth
              inputProps={{ min: 0 }}
            />
            <Typography variant="body2" color="textSecondary">
              Due Fee: {editTotalFee && editPaidFee ? Number(editTotalFee) - Number(editPaidFee) : ''}
            </Typography>
          </Box>
        </DialogContent>
        <DialogActions sx={{ px: 3, pb: 2 }}>
          <Button onClick={handleCloseEditModal} disabled={submitLoading}>Cancel</Button>
          <Button
            onClick={handleSubmitEdit}
            variant="contained"
            color="primary"
            disabled={submitLoading}
          >
            {submitLoading ? 'Saving...' : 'Save'}
          </Button>
        </DialogActions>
      </Dialog>
    </div>
  );
};

export default FeeListPage;
